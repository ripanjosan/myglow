"use client";

import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  User, Moon, Sun, Bell, Scale, Download, Upload,
  Trash2, ChevronRight, Check, X, AlertTriangle
} from "lucide-react";
import PageHeader from "@/components/layout/PageHeader";
import Card from "@/components/ui/Card";
import { db, getSetting, setSetting } from "@/lib/db";
import { useTheme } from "@/components/ui/ThemeProvider";
import { calculateBMI, getBMICategory } from "@/lib/utils";

export default function SettingsPage() {
  const { theme, setTheme } = useTheme();
  const [profile, setProfile] = useState({
    name: "Ripan",
    age: "25",
    height: "170",
    currentWeight: "70",
    goalWeight: "65",
    calorieGoal: "1800",
    proteinGoal: "100",
    waterGoal: "2500",
    stepGoal: "8000",
  });
  const [saved, setSaved] = useState(false);
  const [showReset, setShowReset] = useState(false);
  const [notifPermission, setNotifPermission] = useState<NotificationPermission>("default");
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    loadSettings();
    if ("Notification" in window) {
      setNotifPermission(Notification.permission);
    }
  }, []);

  async function loadSettings() {
    const keys = Object.keys(profile) as (keyof typeof profile)[];
    const values: Record<string, string> = {};
    for (const key of keys) {
      const val = await getSetting(key);
      if (val) values[key] = val;
    }
    setProfile(prev => ({ ...prev, ...values }));
  }

  async function saveSettings() {
    const keys = Object.keys(profile) as (keyof typeof profile)[];
    for (const key of keys) {
      await setSetting(key, profile[key]);
    }
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  async function requestNotifications() {
    if ("Notification" in window) {
      const perm = await Notification.requestPermission();
      setNotifPermission(perm);
    }
  }

  async function exportData() {
    const [mealLogs, waterLogs, weightLogs, habitDefs, habitLogs, moodLogs, journalEntries, plannerItems, settings] = await Promise.all([
      db.mealLogs.toArray(),
      db.waterLogs.toArray(),
      db.weightLogs.toArray(),
      db.habitDefinitions.toArray(),
      db.habitLogs.toArray(),
      db.moodLogs.toArray(),
      db.journalEntries.toArray(),
      db.plannerItems.toArray(),
      db.settings.toArray(),
    ]);

    const data = {
      exportedAt: new Date().toISOString(),
      version: "1.0",
      mealLogs, waterLogs, weightLogs,
      habitDefs, habitLogs, moodLogs,
      journalEntries, plannerItems, settings,
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `myglow-backup-${new Date().toISOString().split("T")[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  async function importData(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      if (!data.version) throw new Error("Invalid backup file");

      if (data.mealLogs?.length) await db.mealLogs.bulkPut(data.mealLogs);
      if (data.waterLogs?.length) await db.waterLogs.bulkPut(data.waterLogs);
      if (data.weightLogs?.length) await db.weightLogs.bulkPut(data.weightLogs);
      if (data.habitDefs?.length) await db.habitDefinitions.bulkPut(data.habitDefs);
      if (data.habitLogs?.length) await db.habitLogs.bulkPut(data.habitLogs);
      if (data.moodLogs?.length) await db.moodLogs.bulkPut(data.moodLogs);
      if (data.journalEntries?.length) await db.journalEntries.bulkPut(data.journalEntries);
      if (data.plannerItems?.length) await db.plannerItems.bulkPut(data.plannerItems);
      if (data.settings?.length) await db.settings.bulkPut(data.settings);

      alert("✅ Data imported successfully! Refresh to see your data.");
    } catch {
      alert("❌ Failed to import. Make sure it's a valid MyGlow backup file.");
    }
  }

  async function resetAllData() {
    await Promise.all([
      db.mealLogs.clear(),
      db.waterLogs.clear(),
      db.weightLogs.clear(),
      db.habitLogs.clear(),
      db.moodLogs.clear(),
      db.journalEntries.clear(),
      db.plannerItems.clear(),
      db.stepLogs.clear(),
    ]);
    setShowReset(false);
    window.location.reload();
  }

  const bmi = calculateBMI(parseFloat(profile.currentWeight), parseFloat(profile.height));
  const bmiInfo = getBMICategory(bmi);

  const field = (label: string, key: keyof typeof profile, suffix?: string, type = "text") => (
    <div>
      <label className="text-xs font-medium text-gray-500 block mb-1.5">{label}{suffix ? ` (${suffix})` : ""}</label>
      <input
        value={profile[key]}
        onChange={e => setProfile(p => ({ ...p, [key]: e.target.value }))}
        className="input-glow w-full"
        type={type}
        inputMode={type === "number" ? "decimal" : "text"}
      />
    </div>
  );

  return (
    <div className="page-container">
      <PageHeader title="Settings" emoji="⚙️" subtitle="Personalize your experience" />

      {/* Profile */}
      <Card className="mb-4">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-glow-pink to-glow-lavender flex items-center justify-center">
            <User size={22} className="text-white" />
          </div>
          <div>
            <p className="font-bold">{profile.name}</p>
            <p className="text-xs text-gray-400">BMI {bmi} · {bmiInfo.label}</p>
          </div>
        </div>

        <div className="space-y-3">
          {field("Name", "name")}
          {field("Age", "age", "years", "number")}
          <div className="grid grid-cols-2 gap-3">
            {field("Height", "height", "cm", "number")}
            {field("Current Weight", "currentWeight", "kg", "number")}
          </div>
          {field("Goal Weight", "goalWeight", "kg", "number")}
        </div>
      </Card>

      {/* Goals */}
      <Card className="mb-4">
        <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">🎯 Daily Goals</p>
        <div className="grid grid-cols-2 gap-3">
          {field("Calorie Goal", "calorieGoal", "kcal", "number")}
          {field("Protein Goal", "proteinGoal", "g", "number")}
          {field("Water Goal", "waterGoal", "ml", "number")}
          {field("Step Goal", "stepGoal", "steps", "number")}
        </div>
      </Card>

      {/* Theme */}
      <Card className="mb-4">
        <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">🎨 Appearance</p>
        <div className="flex gap-3">
          <button
            onClick={() => setTheme("light")}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl text-sm font-semibold transition-all ${
              theme === "light"
                ? "bg-gradient-to-r from-glow-pink to-glow-lavender text-purple-900 shadow-glow"
                : "glass text-gray-500"
            }`}
          >
            <Sun size={16} /> Light
          </button>
          <button
            onClick={() => setTheme("dark")}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl text-sm font-semibold transition-all ${
              theme === "dark"
                ? "bg-gradient-to-r from-glow-pink to-glow-lavender text-purple-900 shadow-glow"
                : "glass text-gray-500"
            }`}
          >
            <Moon size={16} /> Dark
          </button>
        </div>
      </Card>

      {/* Notifications */}
      <Card className="mb-4">
        <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">🔔 Notifications</p>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium">Push Notifications</p>
            <p className="text-xs text-gray-400">
              Status: {notifPermission === "granted" ? "✅ Enabled" : notifPermission === "denied" ? "❌ Blocked" : "Not requested"}
            </p>
          </div>
          {notifPermission !== "granted" && notifPermission !== "denied" && (
            <button onClick={requestNotifications} className="btn-primary py-2 px-4 text-xs">
              Enable
            </button>
          )}
          {notifPermission === "denied" && (
            <p className="text-xs text-red-400">Enable in browser settings</p>
          )}
          {notifPermission === "granted" && (
            <div className="w-8 h-8 rounded-full bg-emerald-100 dark:bg-emerald-900/20 flex items-center justify-center">
              <Check size={16} className="text-emerald-500" />
            </div>
          )}
        </div>
      </Card>

      {/* Save Profile */}
      <motion.button
        whileTap={{ scale: 0.97 }}
        onClick={saveSettings}
        className={`w-full py-4 rounded-2xl font-semibold text-sm transition-all duration-300 mb-4 ${
          saved
            ? "bg-emerald-50 text-emerald-600 border border-emerald-200"
            : "btn-primary"
        }`}
      >
        {saved ? "✅ Settings Saved!" : "Save Settings"}
      </motion.button>

      {/* Data Management */}
      <Card className="mb-4">
        <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">💾 Data Management</p>
        <div className="space-y-2">
          <button
            onClick={exportData}
            className="w-full flex items-center gap-3 p-3.5 rounded-2xl bg-glow-blush/40 dark:bg-dark-surface/50 text-left"
          >
            <div className="w-9 h-9 rounded-xl bg-blue-100 dark:bg-blue-900/20 flex items-center justify-center">
              <Download size={18} className="text-blue-500" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-semibold">Export Data</p>
              <p className="text-xs text-gray-400">Download all your data as JSON</p>
            </div>
            <ChevronRight size={16} className="text-gray-300" />
          </button>

          <button
            onClick={() => fileInputRef.current?.click()}
            className="w-full flex items-center gap-3 p-3.5 rounded-2xl bg-glow-blush/40 dark:bg-dark-surface/50 text-left"
          >
            <div className="w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-900/20 flex items-center justify-center">
              <Upload size={18} className="text-emerald-500" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-semibold">Import Data</p>
              <p className="text-xs text-gray-400">Restore from a backup file</p>
            </div>
            <ChevronRight size={16} className="text-gray-300" />
          </button>

          <input
            ref={fileInputRef}
            type="file"
            accept=".json"
            className="hidden"
            onChange={importData}
          />
        </div>
      </Card>

      {/* Danger Zone */}
      <Card className="mb-8">
        <p className="text-xs font-semibold text-red-400 uppercase tracking-wider mb-3">⚠️ Danger Zone</p>
        <button
          onClick={() => setShowReset(true)}
          className="w-full flex items-center gap-3 p-3.5 rounded-2xl bg-red-50/60 dark:bg-red-900/10 text-left border border-red-100 dark:border-red-900/30"
        >
          <div className="w-9 h-9 rounded-xl bg-red-100 dark:bg-red-900/20 flex items-center justify-center">
            <Trash2 size={18} className="text-red-500" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-semibold text-red-600 dark:text-red-400">Reset All Data</p>
            <p className="text-xs text-red-400">This cannot be undone</p>
          </div>
        </button>
      </Card>

      {/* App Info */}
      <div className="text-center pb-4 text-xs text-gray-300 dark:text-gray-700">
        <p className="font-display text-base font-bold text-gradient mb-1">MyGlow 🌸</p>
        <p>Version 1.0.0 · Powered by Ripan AI</p>
        <p className="mt-1">All data stored locally on your device.</p>
        <p>No servers. No tracking. Just you. 💖</p>
      </div>

      {/* Reset Confirm Modal */}
      <AnimatePresence>
        {showReset && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center px-4"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="glass-card w-full max-w-sm p-6 text-center"
            >
              <div className="w-16 h-16 rounded-2xl bg-red-100 dark:bg-red-900/20 flex items-center justify-center mx-auto mb-4">
                <AlertTriangle size={28} className="text-red-500" />
              </div>
              <h2 className="font-display text-xl font-bold mb-2">Reset All Data?</h2>
              <p className="text-sm text-gray-500 mb-6">
                This will permanently delete all your meals, weight logs, habits, journal entries, and more.
                <strong className="text-red-500"> This cannot be undone.</strong>
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowReset(false)}
                  className="flex-1 py-3 rounded-2xl glass font-semibold text-sm"
                >
                  Cancel
                </button>
                <button
                  onClick={resetAllData}
                  className="flex-1 py-3 rounded-2xl bg-red-500 text-white font-semibold text-sm"
                >
                  Reset Everything
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
