"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, X, Flame, Trophy, Footprints, Dumbbell, Timer, Check } from "lucide-react";
import PageHeader from "@/components/layout/PageHeader";
import Card from "@/components/ui/Card";
import { db, StepLog, getTodayString } from "@/lib/db";
import { format, subDays } from "date-fns";
import { Bar } from "react-chartjs-2";
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Tooltip } from "chart.js";

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip);

interface WorkoutLog {
  id?: number;
  date: string;
  type: string;
  duration: number;  // minutes
  caloriesBurned: number;
  notes?: string;
  createdAt: number;
}

const WORKOUT_TYPES = [
  { emoji: "🚶", label: "Walking" },
  { emoji: "🏃", label: "Running" },
  { emoji: "🚴", label: "Cycling" },
  { emoji: "🏋️", label: "Gym/Weights" },
  { emoji: "🧘", label: "Yoga" },
  { emoji: "🤸", label: "Stretching" },
  { emoji: "💃", label: "Dance/Zumba" },
  { emoji: "🏊", label: "Swimming" },
  { emoji: "🎾", label: "Sports" },
  { emoji: "🏠", label: "Home Workout" },
];

const ACHIEVEMENTS = [
  { id: "first_steps", emoji: "👶", title: "First Steps", description: "Log your first day of steps", condition: (steps: number[]) => steps.length >= 1 },
  { id: "hydration_hero", emoji: "💧", title: "Step Master", description: "Reach 10,000 steps in a day", condition: (steps: number[]) => steps.some(s => s >= 10000) },
  { id: "consistency", emoji: "🔥", title: "Consistency Queen", description: "Log steps for 7 days in a row", condition: (steps: number[]) => steps.filter(s => s > 0).length >= 7 },
  { id: "workout_warrior", emoji: "💪", title: "Workout Warrior", description: "Complete 10 workouts", condition: (_: number[], workouts: WorkoutLog[]) => workouts.length >= 10 },
  { id: "calorie_burner", emoji: "🔥", title: "Calorie Crusher", description: "Burn 500+ calories in one session", condition: (_: number[], workouts: WorkoutLog[]) => workouts.some(w => w.caloriesBurned >= 500) },
  { id: "active_week", emoji: "🌟", title: "Active Week", description: "Work out 5 times this week", condition: (_: number[], workouts: WorkoutLog[]) => workouts.length >= 5 },
];

export default function FitnessPage() {
  const [stepInput, setStepInput] = useState("");
  const [todaySteps, setTodaySteps] = useState(0);
  const [stepGoal, setStepGoal] = useState(8000);
  const [weeklySteps, setWeeklySteps] = useState<number[]>([]);
  const [workouts, setWorkouts] = useState<WorkoutLog[]>([]);
  const [showAddWorkout, setShowAddWorkout] = useState(false);
  const [newWorkout, setNewWorkout] = useState({ type: "Walking", duration: "30", caloriesBurned: "150", notes: "" });
  const [unlockedAchievements, setUnlockedAchievements] = useState<string[]>([]);
  const today = getTodayString();

  useEffect(() => { loadData(); }, []);

  async function loadData() {
    const goalSetting = await db.settings.where("key").equals("stepGoal").first();
    const goal = parseInt(goalSetting?.value || "8000");
    setStepGoal(goal);

    const stepLog = await db.stepLogs.where("date").equals(today).first();
    setTodaySteps(stepLog?.steps || 0);
    if (stepLog?.steps !== undefined) setStepInput(String(stepLog.steps));

    // Weekly steps
    const week: number[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = subDays(new Date(), i).toISOString().split("T")[0];
      const log = await db.stepLogs.where("date").equals(d).first();
      week.push(log?.steps || 0);
    }
    setWeeklySteps(week);

    // Workouts from custom table (stored in settings as JSON for simplicity)
    const workoutData = await db.settings.where("key").equals("workoutLogs").first();
    const allWorkouts: WorkoutLog[] = workoutData ? JSON.parse(workoutData.value) : [];
    setWorkouts(allWorkouts);

    // Check achievements
    const unlocked = ACHIEVEMENTS.filter(a => a.condition(week, allWorkouts)).map(a => a.id);
    setUnlockedAchievements(unlocked);
  }

  async function saveSteps() {
    const steps = parseInt(stepInput) || 0;
    const existing = await db.stepLogs.where("date").equals(today).first();
    if (existing?.id) {
      await db.stepLogs.update(existing.id, { steps, caloriesBurned: Math.round(steps * 0.04), updatedAt: Date.now() });
    } else {
      await db.stepLogs.add({ date: today, steps, caloriesBurned: Math.round(steps * 0.04), createdAt: Date.now() } as StepLog);
    }
    await loadData();
  }

  async function addWorkout() {
    if (!newWorkout.type || !newWorkout.duration) return;
    const workoutData = await db.settings.where("key").equals("workoutLogs").first();
    const existing: WorkoutLog[] = workoutData ? JSON.parse(workoutData.value) : [];
    const newEntry: WorkoutLog = {
      id: Date.now(),
      date: today,
      type: newWorkout.type,
      duration: parseInt(newWorkout.duration),
      caloriesBurned: parseInt(newWorkout.caloriesBurned) || 0,
      notes: newWorkout.notes,
      createdAt: Date.now(),
    };
    const updated = [newEntry, ...existing];
    if (workoutData?.id) {
      await db.settings.update(workoutData.id, { value: JSON.stringify(updated) });
    } else {
      await db.settings.add({ key: "workoutLogs", value: JSON.stringify(updated) });
    }
    setNewWorkout({ type: "Walking", duration: "30", caloriesBurned: "150", notes: "" });
    setShowAdd(false);
    await loadData();
  }

  const [showAdd, setShowAdd] = useState(false);

  const stepPct = Math.min(100, (todaySteps / stepGoal) * 100);
  const weekLabels = Array.from({ length: 7 }, (_, i) => format(subDays(new Date(), 6 - i), "EEE"));
  const totalCalsBurned = workouts.filter(w => w.date === today).reduce((a, w) => a + w.caloriesBurned, 0);

  return (
    <div className="page-container">
      <PageHeader title="Fitness" emoji="🏋️" subtitle="Move your body, feed your soul" />

      {/* Steps Today */}
      <Card className="mb-4">
        <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">👟 Today's Steps</p>
        <div className="flex items-center gap-4 mb-4">
          <div className="relative">
            <svg width="80" height="80" viewBox="0 0 80 80" className="-rotate-90">
              <circle cx="40" cy="40" r="34" fill="none" stroke="rgba(52,211,153,0.12)" strokeWidth="7" />
              <motion.circle
                cx="40" cy="40" r="34"
                fill="none"
                stroke={stepPct >= 100 ? "#34D399" : "#60A5FA"}
                strokeWidth="7"
                strokeLinecap="round"
                strokeDasharray={2 * Math.PI * 34}
                initial={{ strokeDashoffset: 2 * Math.PI * 34 }}
                animate={{ strokeDashoffset: 2 * Math.PI * 34 * (1 - stepPct / 100) }}
                transition={{ duration: 1, ease: "easeOut" }}
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <Footprints size={28} className={stepPct >= 100 ? "text-emerald-400" : "text-blue-400"} />
            </div>
          </div>

          <div className="flex-1">
            <motion.p
              key={todaySteps}
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="font-display text-3xl font-bold text-gradient"
            >
              {todaySteps.toLocaleString()}
            </motion.p>
            <p className="text-sm text-gray-400">/ {stepGoal.toLocaleString()} goal</p>
            <div className="flex gap-3 mt-1 text-xs text-gray-500">
              <span>🔥 {Math.round(todaySteps * 0.04)} kcal</span>
              <span>📍 {(todaySteps * 0.0008).toFixed(1)} km</span>
            </div>
          </div>
        </div>

        <div className="flex gap-2">
          <input
            value={stepInput}
            onChange={e => setStepInput(e.target.value)}
            placeholder="Enter today's steps"
            className="input-glow flex-1"
            type="number"
            inputMode="numeric"
          />
          <button onClick={saveSteps} className="btn-primary px-5">Save</button>
        </div>
        {stepPct >= 100 && (
          <p className="text-center text-xs text-emerald-500 font-semibold mt-2">🎉 Goal reached! Amazing! 🌟</p>
        )}
      </Card>

      {/* Today's Workouts */}
      <Card className="mb-4">
        <div className="flex items-center justify-between mb-3">
          <div>
            <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider">Workouts</p>
            {totalCalsBurned > 0 && (
              <p className="text-xs text-orange-500 font-medium mt-0.5">🔥 {totalCalsBurned} kcal burned today</p>
            )}
          </div>
          <button onClick={() => setShowAdd(true)} className="btn-primary py-2 px-4 text-xs">
            <Plus size={14} /> Add
          </button>
        </div>

        {workouts.filter(w => w.date === today).length === 0 ? (
          <div className="text-center py-6">
            <p className="text-3xl mb-1">🏋️</p>
            <p className="text-sm text-gray-400">No workouts logged today</p>
            <button onClick={() => setShowAdd(true)} className="mt-2 text-xs text-glow-rose font-medium">
              + Log your workout
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            {workouts.filter(w => w.date === today).map(workout => (
              <div key={workout.id} className="flex items-center gap-3 p-3 rounded-xl bg-glow-blush/40 dark:bg-dark-surface/50">
                <span className="text-2xl">{WORKOUT_TYPES.find(t => t.label === workout.type)?.emoji || "🏃"}</span>
                <div className="flex-1">
                  <p className="text-sm font-semibold">{workout.type}</p>
                  <div className="flex gap-3 text-xs text-gray-400">
                    <span className="flex items-center gap-1"><Timer size={11} /> {workout.duration}min</span>
                    <span className="flex items-center gap-1"><Flame size={11} className="text-orange-400" /> {workout.caloriesBurned} kcal</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Weekly Steps */}
      {weeklySteps.some(s => s > 0) && (
        <Card className="mb-4">
          <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">📊 Weekly Steps</p>
          <div className="h-32">
            <Bar
              data={{
                labels: weekLabels,
                datasets: [{
                  data: weeklySteps,
                  backgroundColor: weeklySteps.map((s, i) =>
                    i === 6 ? "rgba(96,165,250,0.9)" : s >= stepGoal ? "rgba(52,211,153,0.7)" : "rgba(147,197,253,0.5)"
                  ),
                  borderRadius: 8,
                }],
              }}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                  x: { grid: { display: false }, ticks: { font: { size: 10 }, color: "#9CA3AF" } },
                  y: { grid: { color: "rgba(0,0,0,0.04)" }, ticks: { font: { size: 9 }, color: "#9CA3AF" } },
                },
              }}
            />
          </div>
          <p className="text-xs text-gray-400 mt-2">
            Weekly total: {weeklySteps.reduce((a, b) => a + b, 0).toLocaleString()} steps
          </p>
        </Card>
      )}

      {/* Achievements */}
      <Card className="mb-4">
        <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">🏆 Achievements</p>
        <div className="grid grid-cols-2 gap-2">
          {ACHIEVEMENTS.map(achievement => {
            const unlocked = unlockedAchievements.includes(achievement.id);
            return (
              <div
                key={achievement.id}
                className={`p-3 rounded-2xl transition-all ${
                  unlocked
                    ? "bg-gradient-to-br from-glow-gold/20 to-amber-100/50 dark:from-glow-gold/10 border border-glow-gold/30"
                    : "bg-gray-50 dark:bg-dark-surface opacity-50"
                }`}
              >
                <p className="text-2xl mb-1">{unlocked ? achievement.emoji : "🔒"}</p>
                <p className="text-xs font-bold">{achievement.title}</p>
                <p className="text-[9px] text-gray-400 mt-0.5">{achievement.description}</p>
              </div>
            );
          })}
        </div>
      </Card>

      {/* Recent Workouts */}
      {workouts.filter(w => w.date !== today).length > 0 && (
        <Card>
          <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">Recent Workouts</p>
          <div className="space-y-2">
            {workouts.filter(w => w.date !== today).slice(0, 5).map(workout => (
              <div key={workout.id} className="flex items-center gap-3 py-2 border-b border-glow-pink/5 last:border-0">
                <span className="text-xl">{WORKOUT_TYPES.find(t => t.label === workout.type)?.emoji || "🏃"}</span>
                <div className="flex-1">
                  <p className="text-sm font-medium">{workout.type}</p>
                  <p className="text-xs text-gray-400">{workout.date}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs font-semibold">{workout.duration}min</p>
                  <p className="text-[9px] text-orange-400">{workout.caloriesBurned} kcal</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Add Workout Modal */}
      <AnimatePresence>
        {showAdd && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-end"
            onClick={e => { if (e.target === e.currentTarget) setShowAdd(false); }}
          >
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="w-full max-w-md mx-auto glass rounded-t-3xl p-5"
            >
              <div className="flex items-center justify-between mb-5">
                <h2 className="font-display text-lg font-bold">Log Workout</h2>
                <button onClick={() => setShowAdd(false)} className="w-8 h-8 rounded-full bg-gray-100 dark:bg-dark-surface flex items-center justify-center">
                  <X size={16} />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-medium text-gray-500 block mb-2">Workout Type</label>
                  <div className="grid grid-cols-5 gap-2">
                    {WORKOUT_TYPES.map(t => (
                      <button
                        key={t.label}
                        onClick={() => setNewWorkout(p => ({ ...p, type: t.label }))}
                        className={`flex flex-col items-center gap-1 p-2 rounded-xl text-[9px] transition-all ${
                          newWorkout.type === t.label
                            ? "bg-glow-pink/30 scale-105 shadow-glow"
                            : "bg-gray-50 dark:bg-dark-surface text-gray-400"
                        }`}
                      >
                        <span className="text-xl">{t.emoji}</span>
                        <span className="truncate">{t.label.split("/")[0]}</span>
                      </button>
                    ))}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-medium text-gray-500 block mb-1.5">Duration (min)</label>
                    <input
                      value={newWorkout.duration}
                      onChange={e => setNewWorkout(p => ({ ...p, duration: e.target.value }))}
                      className="input-glow w-full"
                      type="number"
                      inputMode="numeric"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-gray-500 block mb-1.5">Calories Burned</label>
                    <input
                      value={newWorkout.caloriesBurned}
                      onChange={e => setNewWorkout(p => ({ ...p, caloriesBurned: e.target.value }))}
                      className="input-glow w-full"
                      type="number"
                      inputMode="numeric"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-medium text-gray-500 block mb-1.5">Notes</label>
                  <input
                    value={newWorkout.notes}
                    onChange={e => setNewWorkout(p => ({ ...p, notes: e.target.value }))}
                    className="input-glow w-full"
                    placeholder="e.g. Morning run, felt great!"
                  />
                </div>
              </div>
              <div className="flex gap-3 mt-5">
                <button onClick={() => setShowAdd(false)} className="flex-1 btn-ghost border border-gray-200 dark:border-dark-border py-3">Cancel</button>
                <button onClick={addWorkout} className="flex-1 btn-primary py-3">Save Workout</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
