"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";
import PageHeader from "@/components/layout/PageHeader";
import Card from "@/components/ui/Card";
import { db, MoodLog, getTodayString } from "@/lib/db";
import { format, subDays } from "date-fns";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS, CategoryScale, LinearScale, PointElement,
  LineElement, Tooltip, Filler
} from "chart.js";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Filler);

const MOODS = [
  { value: 1, emoji: "😔", label: "Struggling" },
  { value: 2, emoji: "😐", label: "Meh" },
  { value: 3, emoji: "🙂", label: "Okay" },
  { value: 4, emoji: "😊", label: "Good" },
  { value: 5, emoji: "🌟", label: "Amazing" },
];

const TAGS = ["😴 Tired", "💪 Energetic", "😰 Stressed", "😌 Calm", "💖 Happy", "😢 Sad", "🤒 Unwell", "🎉 Excited", "😤 Frustrated", "🧘 Peaceful", "🌿 Grateful", "🥰 Loved"];

export default function MoodPage() {
  const [todayLog, setTodayLog] = useState<MoodLog | null>(null);
  const [mood, setMood] = useState(3);
  const [energy, setEnergy] = useState(3);
  const [stress, setStress] = useState(2);
  const [sleep, setSleep] = useState(7);
  const [sleepQuality, setSleepQuality] = useState(3);
  const [notes, setNotes] = useState("");
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [saved, setSaved] = useState(false);
  const [weekLogs, setWeekLogs] = useState<MoodLog[]>([]);
  const today = getTodayString();

  useEffect(() => { loadData(); }, []);

  async function loadData() {
    const todayMood = await db.moodLogs.where("date").equals(today).first();
    if (todayMood) {
      setTodayLog(todayMood);
      setMood(todayMood.mood);
      setEnergy(todayMood.energy);
      setStress(todayMood.stress);
      setSleep(todayMood.sleep);
      setSleepQuality(todayMood.sleepQuality);
      setNotes(todayMood.notes || "");
      setSelectedTags(todayMood.tags || []);
      setSaved(true);
    }

    const last7 = Array.from({ length: 7 }, (_, i) => subDays(new Date(), 6 - i).toISOString().split("T")[0]);
    const logs: MoodLog[] = [];
    for (const d of last7) {
      const l = await db.moodLogs.where("date").equals(d).first();
      if (l) logs.push(l);
      else logs.push({ date: d, mood: 0, energy: 0, stress: 0, sleep: 0, sleepQuality: 0, createdAt: 0 } as MoodLog);
    }
    setWeekLogs(logs);
  }

  async function saveMood() {
    const data = { date: today, mood, energy, stress, sleep, sleepQuality, notes, tags: selectedTags, createdAt: Date.now() };
    if (todayLog?.id) {
      await db.moodLogs.update(todayLog.id, data);
    } else {
      await db.moodLogs.add(data as MoodLog);
    }
    setSaved(true);
    await loadData();
  }

  function toggleTag(tag: string) {
    setSelectedTags(prev => prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]);
    setSaved(false);
  }

  const weekLabels = Array.from({ length: 7 }, (_, i) => format(subDays(new Date(), 6 - i), "EEE"));

  return (
    <div className="page-container">
      <PageHeader title="Mood" emoji="💝" subtitle="How are you feeling today?" />

      {/* Mood Selector */}
      <Card className="mb-4">
        <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-4">Today's Mood</p>
        <div className="flex justify-between mb-2">
          {MOODS.map(m => (
            <motion.button
              key={m.value}
              whileTap={{ scale: 0.85 }}
              onClick={() => { setMood(m.value); setSaved(false); }}
              className={`flex flex-col items-center gap-1.5 p-3 rounded-2xl transition-all duration-200 ${
                mood === m.value
                  ? "bg-gradient-to-b from-glow-pink/30 to-glow-lavender/20 shadow-glow border border-glow-pink/30 scale-110"
                  : "hover:bg-glow-blush dark:hover:bg-dark-surface"
              }`}
            >
              <motion.span
                className="text-3xl"
                animate={{ scale: mood === m.value ? 1.15 : 1 }}
                transition={{ type: "spring", stiffness: 400 }}
              >
                {m.emoji}
              </motion.span>
              <span className={`text-[9px] font-semibold ${mood === m.value ? "text-glow-rose" : "text-gray-400"}`}>
                {m.label}
              </span>
            </motion.button>
          ))}
        </div>
      </Card>

      {/* Sliders */}
      <Card className="mb-4 space-y-5">
        <SliderRow
          label="⚡ Energy"
          value={energy}
          onChange={v => { setEnergy(v); setSaved(false); }}
          min={1} max={5}
          gradient="from-red-300 to-emerald-400"
          labels={["Drained", "Low", "Okay", "High", "Pumped"]}
        />
        <SliderRow
          label="😰 Stress"
          value={stress}
          onChange={v => { setStress(v); setSaved(false); }}
          min={1} max={5}
          gradient="from-emerald-300 to-red-400"
          labels={["None", "Low", "Medium", "High", "Overwhelmed"]}
          reverse
        />
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider">😴 Sleep Hours</label>
            <span className="text-sm font-bold">{sleep}h</span>
          </div>
          <input
            type="range" min={3} max={12} step={0.5}
            value={sleep}
            onChange={e => { setSleep(parseFloat(e.target.value)); setSaved(false); }}
            className="w-full accent-pink-300"
          />
          <div className="flex justify-between text-[9px] text-gray-400 mt-0.5">
            <span>3h</span><span>6h</span><span>8h</span><span>10h</span><span>12h</span>
          </div>
        </div>
        <SliderRow
          label="🌙 Sleep Quality"
          value={sleepQuality}
          onChange={v => { setSleepQuality(v); setSaved(false); }}
          min={1} max={5}
          gradient="from-indigo-300 to-violet-400"
          labels={["Poor", "Fair", "Okay", "Good", "Great"]}
        />
      </Card>

      {/* Tags */}
      <Card className="mb-4">
        <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">How do you feel? (select all that apply)</p>
        <div className="flex flex-wrap gap-2">
          {TAGS.map(tag => (
            <button
              key={tag}
              onClick={() => toggleTag(tag)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                selectedTags.includes(tag)
                  ? "bg-gradient-to-r from-glow-pink to-glow-lavender text-purple-900 shadow-glow"
                  : "bg-glow-blush dark:bg-dark-surface text-gray-500 border border-gray-100 dark:border-dark-border"
              }`}
            >
              {tag}
            </button>
          ))}
        </div>
      </Card>

      {/* Notes */}
      <Card className="mb-4">
        <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-2">Reflection</p>
        <textarea
          value={notes}
          onChange={e => { setNotes(e.target.value); setSaved(false); }}
          placeholder="How was your day? What are you feeling? ..."
          className="input-glow w-full min-h-[100px] resize-none"
        />
      </Card>

      {/* Save Button */}
      <motion.button
        whileTap={{ scale: 0.97 }}
        onClick={saveMood}
        className={`w-full py-4 rounded-2xl font-semibold text-sm transition-all duration-300 ${
          saved
            ? "bg-emerald-50 text-emerald-600 border border-emerald-200"
            : "btn-primary"
        }`}
      >
        {saved ? "✅ Mood Saved!" : "Save Today's Mood"}
      </motion.button>

      {/* Weekly Chart */}
      {weekLogs.some(l => l.mood > 0) && (
        <Card className="mt-4">
          <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">Mood This Week</p>
          <div className="h-32">
            <Line
              data={{
                labels: weekLabels,
                datasets: [
                  {
                    label: "Mood",
                    data: weekLogs.map(l => l.mood || null),
                    borderColor: "#F9C6D0",
                    backgroundColor: "rgba(249,198,208,0.15)",
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: "#F9C6D0",
                    pointRadius: 5,
                    pointHoverRadius: 7,
                  },
                  {
                    label: "Energy",
                    data: weekLogs.map(l => l.energy || null),
                    borderColor: "#C8B6E2",
                    backgroundColor: "transparent",
                    tension: 0.4,
                    pointBackgroundColor: "#C8B6E2",
                    pointRadius: 4,
                  },
                ],
              }}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                  y: {
                    min: 1, max: 5,
                    ticks: {
                      stepSize: 1,
                      callback: v => MOODS.find(m => m.value === v)?.emoji || v,
                      font: { size: 12 },
                      color: "#9CA3AF",
                    },
                    grid: { color: "rgba(0,0,0,0.04)" },
                  },
                  x: { grid: { display: false }, ticks: { font: { size: 10 }, color: "#9CA3AF" } },
                },
              }}
            />
          </div>
          <div className="flex items-center gap-4 mt-2 text-xs text-gray-400">
            <span className="flex items-center gap-1"><span className="w-3 h-1 rounded-full bg-glow-pink inline-block" /> Mood</span>
            <span className="flex items-center gap-1"><span className="w-3 h-1 rounded-full bg-glow-lavender inline-block" /> Energy</span>
          </div>
        </Card>
      )}
    </div>
  );
}

function SliderRow({ label, value, onChange, min, max, gradient, labels, reverse }: {
  label: string; value: number; onChange: (v: number) => void;
  min: number; max: number; gradient: string; labels: string[]; reverse?: boolean;
}) {
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <label className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider">{label}</label>
        <span className="text-xs font-bold text-glow-rose">{labels[value - 1]}</span>
      </div>
      <div className={`h-2 rounded-full bg-gradient-to-r ${gradient} mb-1`} />
      <input
        type="range" min={min} max={max} step={1}
        value={value}
        onChange={e => onChange(parseInt(e.target.value))}
        className="w-full accent-pink-300 -mt-2"
      />
    </div>
  );
}
