"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import {
  Heart, Sparkles, Calendar, Bot, Weight,
  Dumbbell, Settings, ChevronRight, TrendingUp
} from "lucide-react";
import PageHeader from "@/components/layout/PageHeader";
import Card from "@/components/ui/Card";

const MORE_ITEMS = [
  {
    href: "/mood",
    icon: Heart,
    label: "Mood Tracker",
    description: "Log energy, stress & sleep",
    color: "#F9C6D0",
    emoji: "💝",
  },
  {
    href: "/manifestation",
    icon: Sparkles,
    label: "Journal",
    description: "369 method, gratitude & affirmations",
    color: "#C8B6E2",
    emoji: "✨",
  },
  {
    href: "/planner",
    icon: Calendar,
    label: "Daily Planner",
    description: "Your daily routine & tasks",
    color: "#93C5FD",
    emoji: "📅",
  },
  {
    href: "/ai",
    icon: Bot,
    label: "Ripan AI",
    description: "Your personal wellness companion",
    color: "#FCD34D",
    emoji: "🤖",
  },
  {
    href: "/weight",
    icon: Weight,
    label: "Weight Tracker",
    description: "Log weight, BMI & goal progress",
    color: "#6EE7B7",
    emoji: "⚖️",
  },
  {
    href: "/fitness",
    icon: Dumbbell,
    label: "Fitness",
    description: "Steps, workouts & achievements",
    color: "#FB923C",
    emoji: "🏋️",
  },
  {
    href: "/progress",
    icon: TrendingUp,
    label: "Progress",
    description: "Charts, trends & reports",
    color: "#A78BFA",
    emoji: "📊",
  },
  {
    href: "/settings",
    icon: Settings,
    label: "Settings",
    description: "Profile, theme & data",
    color: "#94A3B8",
    emoji: "⚙️",
  },
];

export default function MorePage() {
  return (
    <div className="page-container">
      <PageHeader title="More" emoji="🌸" subtitle="All your wellness tools" />

      {/* Ripan AI Feature Banner */}
      <Link href="/ai">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-5 rounded-3xl p-5 overflow-hidden relative cursor-pointer active:scale-98 transition-transform"
          style={{
            background: "linear-gradient(135deg, #F9C6D0 0%, #C8B6E2 50%, #D4A853 100%)",
          }}
        >
          <div className="absolute top-0 right-0 w-40 h-40 opacity-20">
            <Sparkles size={160} className="text-white" />
          </div>
          <p className="text-xs font-semibold text-purple-800/70 uppercase tracking-wider mb-1">Featured</p>
          <h2 className="font-display text-2xl font-bold text-purple-900 mb-1">Ripan AI 🤖</h2>
          <p className="text-sm text-purple-800/80 mb-3">Your personal wellness companion powered by AI. Get personalized advice, meal plans, and motivation.</p>
          <div className="flex items-center gap-1 text-purple-800 font-semibold text-sm">
            Chat now <ChevronRight size={16} />
          </div>
        </motion.div>
      </Link>

      {/* All Sections */}
      <div className="space-y-2.5">
        {MORE_ITEMS.map((item, i) => (
          <motion.div
            key={item.href}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.05 }}
          >
            <Link href={item.href}>
              <div className="glass-card p-4 flex items-center gap-4 active:scale-98 transition-transform card-hover">
                <div
                  className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0"
                  style={{ background: `${item.color}25` }}
                >
                  {item.emoji}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm">{item.label}</p>
                  <p className="text-xs text-gray-400 truncate">{item.description}</p>
                </div>
                <ChevronRight size={18} className="text-gray-300 flex-shrink-0" />
              </div>
            </Link>
          </motion.div>
        ))}
      </div>

      {/* App Info */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="mt-8 text-center"
      >
        <p className="text-2xl mb-2">🌸</p>
        <p className="font-display text-lg font-bold text-gradient">MyGlow</p>
        <p className="text-xs text-gray-400 mt-0.5">Powered by Ripan AI</p>
        <p className="text-xs text-gray-300 mt-1">Glow into your best self.</p>
        <p className="text-[10px] text-gray-200 dark:text-gray-700 mt-3">v1.0.0 · Made with 💖</p>
      </motion.div>
    </div>
  );
}
