"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { BarChart2, TrendingUp, TrendingDown, Minus } from "lucide-react";
import PageHeader from "@/components/layout/PageHeader";
import Card from "@/components/ui/Card";
import { db, calculateGlowScore, getTodayString } from "@/lib/db";
import { format, subDays, startOfWeek, endOfWeek } from "date-fns";
import {
  Chart as ChartJS, CategoryScale, LinearScale, BarElement,
  PointElement, LineElement, Tooltip, Filler, ArcElement, Legend
} from "chart.js";
import { Line, Bar, Doughnut } from "react-chartjs-2";

ChartJS.register(CategoryScale, LinearScale, BarElement, PointElement, LineElement, Tooltip, Filler, ArcElement, Legend);

type Period = "week" | "month";

interface ChartData {
  labels: string[];
  calories: number[];
  protein: number[];
  water: number[];
  weight: number[];
  mood: (number | null)[];
  glowScores: number[];
}

export default function ProgressPage() {
  const [period, setPeriod] = useState<Period>("week");
  const [data, setData] = useState<ChartData | null>(null);
  const [totals, setTotals] = useState({ avgCalories: 0, avgProtein: 0, avgWater: 0, avgMood: 0 });
  const [calorieGoal, setCalorieGoal] = useState(1800);
  const [waterGoal, setWaterGoal] = useState(2500);

  useEffect(() => { loadData(); }, [period]);

  async function loadData() {
    const days = period === "week" ? 7 : 30;
    const labels: string[] = [];
    const calories: number[] = [];
    const protein: number[] = [];
    const water: number[] = [];
    const weight: number[] = [];
    const mood: (number | null)[] = [];
    const glowScores: number[] = [];

    const cg = await db.settings.where("key").equals("calorieGoal").first();
    const wg = await db.settings.where("key").equals("waterGoal").first();
    setCalorieGoal(parseInt(cg?.value || "1800"));
    setWaterGoal(parseInt(wg?.value || "2500"));

    for (let i = days - 1; i >= 0; i--) {
      const d = subDays(new Date(), i);
      const dateStr = d.toISOString().split("T")[0];
      labels.push(format(d, days === 7 ? "EEE" : "d MMM"));

      const mealLogs = await db.mealLogs.where("date").equals(dateStr).toArray();
      const dayCalories = mealLogs.reduce((a, l) => a + l.calories, 0);
      const dayProtein = mealLogs.reduce((a, l) => a + l.protein, 0);
      calories.push(Math.round(dayCalories));
      protein.push(Math.round(dayProtein));

      const waterLogs = await db.waterLogs.where("date").equals(dateStr).toArray();
      water.push(waterLogs.reduce((a, l) => a + l.amount, 0));

      const weightLog = await db.weightLogs.where("date").equals(dateStr).first();
      weight.push(weightLog?.weight || 0);

      const moodLog = await db.moodLogs.where("date").equals(dateStr).first();
      mood.push(moodLog?.mood ?? null);

      const score = await calculateGlowScore(dateStr);
      glowScores.push(score);
    }

    setData({ labels, calories, protein, water, weight, mood, glowScores });

    const nonZeroCalories = calories.filter(c => c > 0);
    const nonZeroWater = water.filter(w => w > 0);
    const nonZeroMood = mood.filter(m => m !== null) as number[];

    setTotals({
      avgCalories: nonZeroCalories.length ? Math.round(nonZeroCalories.reduce((a, b) => a + b) / nonZeroCalories.length) : 0,
      avgProtein: Math.round(protein.filter(p => p > 0).reduce((a, b) => a + b, 0) / Math.max(1, protein.filter(p => p > 0).length)),
      avgWater: nonZeroWater.length ? Math.round(nonZeroWater.reduce((a, b) => a + b) / nonZeroWater.length) : 0,
      avgMood: nonZeroMood.length ? parseFloat((nonZeroMood.reduce((a, b) => a + b) / nonZeroMood.length).toFixed(1)) : 0,
    });
  }

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      x: { grid: { display: false }, ticks: { font: { size: 9 }, color: "#9CA3AF" } },
      y: { grid: { color: "rgba(0,0,0,0.04)" }, ticks: { font: { size: 9 }, color: "#9CA3AF" } },
    },
  };

  return (
    <div className="page-container">
      <PageHeader title="Progress" emoji="📊" subtitle="Your wellness journey" />

      {/* Period Toggle */}
      <div className="flex gap-2 mb-4">
        {(["week", "month"] as Period[]).map(p => (
          <button
            key={p}
            onClick={() => setPeriod(p)}
            className={`flex-1 py-2.5 rounded-2xl text-sm font-semibold transition-all ${
              period === p
                ? "bg-gradient-to-r from-glow-pink to-glow-lavender text-purple-900 shadow-glow"
                : "glass text-gray-500"
            }`}
          >
            {p === "week" ? "This Week" : "This Month"}
          </button>
        ))}
      </div>

      {/* Summary Stats */}
      {data && (
        <div className="grid grid-cols-2 gap-3 mb-4">
          <StatCard label="Avg. Calories" value={`${totals.avgCalories}`} unit="kcal" goal={calorieGoal} icon="🔥" />
          <StatCard label="Avg. Water" value={Math.round(totals.avgWater / 100) * 100 > 0 ? `${(totals.avgWater/1000).toFixed(1)}L` : "—"} goal={waterGoal} icon="💧" />
          <StatCard label="Avg. Protein" value={`${totals.avgProtein}g`} icon="💪" />
          <StatCard label="Avg. Mood" value={totals.avgMood > 0 ? `${totals.avgMood}/5` : "—"} icon="😊" />
        </div>
      )}

      {/* Glow Score History */}
      {data && (
        <Card className="mb-4">
          <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">✨ Glow Score</p>
          <div className="h-36">
            <Line
              data={{
                labels: data.labels,
                datasets: [{
                  data: data.glowScores,
                  borderColor: "#F9C6D0",
                  backgroundColor: "rgba(249,198,208,0.15)",
                  fill: true,
                  tension: 0.4,
                  pointBackgroundColor: "#F9C6D0",
                  pointRadius: 4,
                }],
              }}
              options={{ ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, min: 0, max: 100 } } }}
            />
          </div>
          <div className="flex items-center justify-between mt-2 text-xs">
            <span className="text-gray-400">Avg: {data.glowScores.filter(s => s > 0).length ? Math.round(data.glowScores.filter(s => s > 0).reduce((a, b) => a + b) / data.glowScores.filter(s => s > 0).length) : 0}/100</span>
            <span className="text-gray-400">Best: {Math.max(...data.glowScores)}/100</span>
          </div>
        </Card>
      )}

      {/* Calories */}
      {data && (
        <Card className="mb-4">
          <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">🔥 Calories</p>
          <div className="h-36">
            <Bar
              data={{
                labels: data.labels,
                datasets: [{
                  data: data.calories,
                  backgroundColor: data.calories.map(c =>
                    c > calorieGoal ? "rgba(239,68,68,0.6)" : c > 0 ? "rgba(249,198,208,0.8)" : "rgba(249,198,208,0.2)"
                  ),
                  borderRadius: 6,
                }],
              }}
              options={{
                ...chartOptions,
                plugins: {
                  ...chartOptions.plugins,
                  annotation: {},
                },
              }}
            />
          </div>
          <div className="flex gap-3 mt-2 text-xs text-gray-400">
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-glow-pink inline-block" /> Under goal</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-400 inline-block" /> Over goal</span>
          </div>
        </Card>
      )}

      {/* Water */}
      {data && (
        <Card className="mb-4">
          <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">💧 Water Intake</p>
          <div className="h-36">
            <Bar
              data={{
                labels: data.labels,
                datasets: [{
                  data: data.water.map(w => w / 1000),
                  backgroundColor: data.water.map(w =>
                    w >= waterGoal ? "rgba(52,211,153,0.7)" : w > 0 ? "rgba(147,197,253,0.7)" : "rgba(147,197,253,0.2)"
                  ),
                  borderRadius: 6,
                }],
              }}
              options={{
                ...chartOptions,
                scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, ticks: { ...chartOptions.scales.y.ticks, callback: (v: unknown) => `${v}L` } } },
              }}
            />
          </div>
        </Card>
      )}

      {/* Weight Trend */}
      {data && data.weight.some(w => w > 0) && (
        <Card className="mb-4">
          <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">⚖️ Weight</p>
          <div className="h-36">
            <Line
              data={{
                labels: data.labels,
                datasets: [{
                  data: data.weight.map(w => w || null),
                  borderColor: "#C8B6E2",
                  backgroundColor: "rgba(200,182,226,0.1)",
                  fill: true,
                  tension: 0.4,
                  pointBackgroundColor: "#C8B6E2",
                  pointRadius: 5,
                  spanGaps: true,
                }],
              }}
              options={{ ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, ticks: { ...chartOptions.scales.y.ticks, callback: (v: unknown) => `${v}kg` } } } }}
            />
          </div>
        </Card>
      )}

      {/* Protein */}
      {data && (
        <Card className="mb-4">
          <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">💪 Protein</p>
          <div className="h-28">
            <Bar
              data={{
                labels: data.labels,
                datasets: [{
                  data: data.protein,
                  backgroundColor: "rgba(200,182,226,0.7)",
                  borderRadius: 6,
                }],
              }}
              options={{ ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, ticks: { ...chartOptions.scales.y.ticks, callback: (v: unknown) => `${v}g` } } } }}
            />
          </div>
        </Card>
      )}

      {/* Mood Trend */}
      {data && data.mood.some(m => m !== null) && (
        <Card className="mb-4">
          <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">💝 Mood Trend</p>
          <div className="h-28">
            <Line
              data={{
                labels: data.labels,
                datasets: [{
                  data: data.mood,
                  borderColor: "#F9C6D0",
                  backgroundColor: "rgba(249,198,208,0.15)",
                  fill: true,
                  tension: 0.4,
                  pointBackgroundColor: "#F9C6D0",
                  pointRadius: 5,
                  spanGaps: true,
                }],
              }}
              options={{
                ...chartOptions,
                scales: {
                  ...chartOptions.scales,
                  y: { ...chartOptions.scales.y, min: 1, max: 5, ticks: { ...chartOptions.scales.y.ticks, stepSize: 1 } },
                },
              }}
            />
          </div>
        </Card>
      )}
    </div>
  );
}

function StatCard({ label, value, unit, goal, icon }: {
  label: string; value: string; unit?: string; goal?: number; icon: string;
}) {
  return (
    <Card delay={0.05}>
      <p className="text-lg mb-0.5">{icon}</p>
      <p className="text-xs text-gray-400 font-medium">{label}</p>
      <p className="font-display text-xl font-bold text-gradient">
        {value}
        {unit && <span className="text-sm font-normal text-gray-400 ml-0.5">{unit}</span>}
      </p>
    </Card>
  );
}
