"use client";

import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Sparkles, RotateCcw, Loader2 } from "lucide-react";
import PageHeader from "@/components/layout/PageHeader";
import Card from "@/components/ui/Card";
import { db, getTodayNutrition, getTodayWater, getSetting, getTodayString } from "@/lib/db";
import { formatWater, calculateBMI } from "@/lib/utils";

interface Message {
  role: "user" | "assistant";
  content: string;
}

const QUICK_PROMPTS = [
  "🥗 Suggest a healthy Indian dinner for tonight",
  "💪 How much protein did I get today?",
  "📊 Analyze my nutrition today",
  "🛒 Create a weekly grocery list",
  "🌿 Give me a weight loss tip",
  "✨ Write me a manifestation affirmation",
  "💧 Am I drinking enough water?",
  "🎯 What should I focus on this week?",
];

const SYSTEM_PROMPT = `You are Ripan AI, a warm, caring, and knowledgeable personal wellness companion for Ripan. She is an Indian woman who eats mostly vegetarian Indian food (chapati, dal, paneer, rice, sabzi, etc.).

Your personality:
- Warm, encouraging, and gentle — never judgmental or guilt-inducing
- Knowledgeable about Indian cuisine, vegetarian nutrition, and wellness
- Personal — you know her name is Ripan and speak directly to her
- Practical — give specific, actionable advice
- Motivating — celebrate her wins, no matter how small

You can help with:
- Analyzing nutrition and suggesting improvements
- Indian vegetarian meal ideas and recipes
- Weight management (gentle, sustainable approach)
- Hydration reminders and tips
- Habit formation and mindset coaching
- Manifestation and journaling prompts
- Grocery lists for Indian vegetarian meals
- Wellness tips specific to Indian lifestyle

Always:
- Use her name (Ripan) naturally in conversation
- Reference Indian foods and culture appropriately
- Be concise but thorough
- End responses with a gentle encouragement
- Use emojis naturally to keep things warm and friendly

Never:
- Be harsh, critical, or guilt-trip her
- Give extreme diet advice
- Recommend expensive supplements without alternatives
- Be generic — always be specific to her context`;

export default function AIPage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [context, setContext] = useState<string>("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    loadContext();
    setMessages([{
      role: "assistant",
      content: "Namaste Ripan! 🌸 I'm Ripan AI, your personal wellness companion. I'm here to help you with nutrition advice, meal suggestions, healthy habits, and so much more. What's on your mind today? ✨"
    }]);
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function loadContext() {
    const today = getTodayString();
    const [nutrition, water, name, calorieGoal, proteinGoal, waterGoal, weight, height, age] = await Promise.all([
      getTodayNutrition(today),
      getTodayWater(today),
      getSetting("name"),
      getSetting("calorieGoal"),
      getSetting("proteinGoal"),
      getSetting("waterGoal"),
      getSetting("currentWeight"),
      getSetting("height"),
      getSetting("age"),
    ]);

    const weightNum = parseFloat(weight || "70");
    const heightNum = parseFloat(height || "170");
    const bmi = calculateBMI(weightNum, heightNum);

    const moodLog = await db.moodLogs.where("date").equals(today).first();
    const activeHabits = await db.habitDefinitions.where("isActive").equals(1).toArray();
    const completedHabits = await db.habitLogs.where("date").equals(today).filter(l => l.completed).count();

    setContext(`
Today's Data for ${name || "Ripan"}:
- Date: ${today}
- Calories: ${Math.round(nutrition.calories)} / ${calorieGoal || 1800} kcal consumed
- Protein: ${Math.round(nutrition.protein)}g (goal: ${proteinGoal || 100}g)
- Carbs: ${Math.round(nutrition.carbs)}g
- Fat: ${Math.round(nutrition.fat)}g
- Water: ${formatWater(water)} / ${formatWater(parseInt(waterGoal || "2500"))}
- Current Weight: ${weightNum}kg, Height: ${heightNum}cm, BMI: ${bmi}
- Age: ${age || "25"}
- Mood today: ${moodLog ? `${moodLog.mood}/5` : "Not logged"}
- Habits: ${completedHabits}/${activeHabits.length} completed
- Diet: Mostly Indian vegetarian food
`);
  }

  async function sendMessage(text?: string) {
    const userMessage = text || input.trim();
    if (!userMessage || loading) return;

    setInput("");
    setMessages(prev => [...prev, { role: "user", content: userMessage }]);
    setLoading(true);

    try {
      const conversationHistory = [
        ...messages.slice(-8), // Last 8 messages for context window
        { role: "user" as const, content: userMessage },
      ];

      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          system: SYSTEM_PROMPT + "\n\nCurrent user data:\n" + context,
          messages: conversationHistory.map(m => ({
            role: m.role,
            content: m.content,
          })),
        }),
      });

      const data = await response.json();
      const reply = data.content?.map((c: { type: string; text: string }) => c.type === "text" ? c.text : "").join("") || "I'm sorry, I couldn't process that. Please try again! 💕";

      setMessages(prev => [...prev, { role: "assistant", content: reply }]);
    } catch (error) {
      setMessages(prev => [...prev, {
        role: "assistant",
        content: "I'm having trouble connecting right now 🌸 Please check your internet and try again. In the meantime, remember to stay hydrated! 💧"
      }]);
    }
    setLoading(false);
    setTimeout(() => inputRef.current?.focus(), 100);
  }

  function clearChat() {
    setMessages([{
      role: "assistant",
      content: "Namaste Ripan! 🌸 Fresh start! I'm here and ready to help you on your wellness journey. What would you like to explore? ✨"
    }]);
  }

  return (
    <div className="flex flex-col h-dvh max-w-md mx-auto">
      {/* Header */}
      <div className="px-4 pt-4 pb-2 glass sticky top-0 z-10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-glow-pink to-glow-lavender flex items-center justify-center shadow-glow animate-pulse-glow">
              <Sparkles size={20} className="text-white" />
            </div>
            <div>
              <h1 className="font-display font-bold text-gradient">Ripan AI</h1>
              <p className="text-[10px] text-gray-400">Your personal wellness companion</p>
            </div>
          </div>
          <button onClick={clearChat} className="w-8 h-8 rounded-xl glass flex items-center justify-center">
            <RotateCcw size={15} className="text-gray-400" />
          </button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 pb-36">
        <AnimatePresence initial={false}>
          {messages.map((message, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${message.role === "user" ? "justify-end" : "justify-start"} gap-2`}
            >
              {message.role === "assistant" && (
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-glow-pink to-glow-lavender flex items-center justify-center flex-shrink-0 mt-1 shadow-glow">
                  <Sparkles size={14} className="text-white" />
                </div>
              )}
              <div
                className={`max-w-[80%] px-4 py-3 rounded-3xl text-sm leading-relaxed ${
                  message.role === "user"
                    ? "bg-gradient-to-r from-glow-pink to-glow-lavender text-purple-900 rounded-br-lg"
                    : "glass-card rounded-bl-lg"
                }`}
              >
                <p className="whitespace-pre-wrap">{message.content}</p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {loading && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-2 items-center">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-glow-pink to-glow-lavender flex items-center justify-center shadow-glow">
              <Sparkles size={14} className="text-white" />
            </div>
            <div className="glass-card px-4 py-3 rounded-3xl rounded-bl-lg flex items-center gap-2">
              <Loader2 size={14} className="animate-spin text-glow-rose" />
              <span className="text-xs text-gray-400">Ripan AI is thinking...</span>
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompts */}
      {messages.length <= 2 && (
        <div className="px-4 pb-2">
          <p className="text-[10px] text-gray-400 font-medium mb-2 uppercase tracking-wider">Suggestions</p>
          <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
            {QUICK_PROMPTS.map(prompt => (
              <button
                key={prompt}
                onClick={() => sendMessage(prompt)}
                className="flex-shrink-0 px-3 py-2 rounded-2xl glass text-xs font-medium text-gray-600 dark:text-gray-300 active:scale-95 transition-transform whitespace-nowrap"
              >
                {prompt}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="px-4 pb-safe glass border-t border-white/20 dark:border-white/5 pt-3"
        style={{ paddingBottom: `max(16px, calc(env(safe-area-inset-bottom) + 70px))` }}>
        <div className="flex gap-2 items-end">
          <div className="flex-1 relative">
            <input
              ref={inputRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
              placeholder="Ask Ripan AI anything..."
              className="input-glow w-full pr-4"
              disabled={loading}
            />
          </div>
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={() => sendMessage()}
            disabled={!input.trim() || loading}
            className={`w-11 h-11 rounded-2xl flex items-center justify-center flex-shrink-0 transition-all ${
              input.trim() && !loading
                ? "bg-gradient-to-br from-glow-pink to-glow-lavender shadow-glow"
                : "bg-gray-100 dark:bg-dark-surface"
            }`}
          >
            {loading ? (
              <Loader2 size={18} className="animate-spin text-gray-400" />
            ) : (
              <Send size={18} className={input.trim() ? "text-white" : "text-gray-300"} />
            )}
          </motion.button>
        </div>
      </div>
    </div>
  );
}
