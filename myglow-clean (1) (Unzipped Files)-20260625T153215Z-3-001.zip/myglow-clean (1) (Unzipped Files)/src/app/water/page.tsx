"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Droplets, Bell, Trash2 } from "lucide-react";
import PageHeader from "@/components/layout/PageHeader";
import Card from "@/components/ui/Card";
import { db, WaterLog, getTodayWater, getTodayString } from "@/lib/db";
import { formatWater } from "@/lib/utils";
import { format, subDays } from "date-fns";
import { Bar } from "react-chartjs-2";
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Tooltip } from "chart.js";

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip);

const QUICK_AMOUNTS = [150, 200, 250, 350, 500];
const QUICK_LABELS = ["☕ Small", "🥤 Glass", "💧 Cup", "🍶 Large", "🍼 Bottle"];

export default function WaterPage() {
  const [water, setWater] = useState(0);
  const [waterGoal, setWaterGoal] = useState(2500);
  const [logs, setLogs] = useState<WaterLog[]>([]);
  const [weekData, setWeekData] = useState<number[]>([]);
  const [customAmount, setCustomAmount] = useState("");
  const [showCustom, setShowCustom] = useState(false);
  const today = getTodayString();

  useEffect(() => { loadData(); }, []);

  async function loadData() {
    const goalSetting = await db.settings.where("key").equals("waterGoal").first();
    const goal = parseInt(goalSetting?.value || "2500");
    setWaterGoal(goal);

    const todayLogs = await db.waterLogs.where("date").equals(today).reverse().sortBy("createdAt");
    setLogs(todayLogs);
    setWater(todayLogs.reduce((a, l) => a + l.amount, 0));

    // Weekly data
    const week: number[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = subDays(new Date(), i).toISOString().split("T")[0];
      const dayLogs = await db.waterLogs.where("date").equals(d).toArray();
      week.push(dayLogs.reduce((a, l) => a + l.amount, 0));
    }
    setWeekData(week);
  }

  async function addWater(amount: number) {
    await db.waterLogs.add({ date: today, amount, createdAt: Date.now() });
    await loadData();
  }

  async function removeLog(id: number) {
    await db.waterLogs.delete(id);
    await loadData();
  }

  async function addCustom() {
    const amount = parseInt(customAmount);
    if (!amount || amount <= 0) return;
    await addWater(amount);
    setCustomAmount("");
    setShowCustom(false);
  }

  async function requestNotificationPermission() {
    if ("Notification" in window) {
      const perm = await Notification.requestPermission();
      if (perm === "granted") {
        new Notification("💧 Water Reminder", {
          body: "Time to drink water! Stay hydrated 🌸",
          icon: "/icons/icon-192.png",
        });
      }
    }
  }

  const pct = Math.min(100, (water / waterGoal) * 100);
  const remaining = Math.max(0, waterGoal - water);
  const isGoalMet = water >= waterGoal;

  const weekLabels = Array.from({ length: 7 }, (_, i) =>
    format(subDays(new Date(), 6 - i), "EEE")
  );

  return (
    <div className="page-container">
      <PageHeader
        title="Water"
        emoji="💧"
        subtitle="Stay hydrated, glow naturally"
        rightElement={
          <button onClick={requestNotificationPermission} className="w-9 h-9 rounded-xl glass flex items-center justify-center">
            <Bell size={18} className="text-blue-400" />
          </button>
        }
      />

      {/* Water Bottle Visualization */}
      <Card className="mb-4 flex flex-col items-center py-6">
        <div className="relative mb-4">
          <WaterBottle pct={pct} />
          {isGoalMet && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="absolute -top-2 -right-2 text-2xl"
            >
              🎉
            </motion.div>
          )}
        </div>

        <motion.div
          key={water}
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="text-center mb-2"
        >
          <p className="font-display text-4xl font-bold text-gradient">{formatWater(water)}</p>
          <p className="text-sm text-gray-400 mt-0.5">of {formatWater(waterGoal)} goal</p>
        </motion.div>

        {isGoalMet ? (
          <div className="bg-emerald-50 dark:bg-emerald-900/20 rounded-2xl px-4 py-2 text-sm text-emerald-600 font-semibold">
            🎉 Goal achieved! Great job!
          </div>
        ) : (
          <p className="text-sm text-gray-400">{formatWater(remaining)} more to reach your goal</p>
        )}

        {/* Progress bar */}
        <div className="w-full mt-4 h-3 rounded-full bg-blue-50 dark:bg-blue-900/20 overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${pct}%` }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="h-full rounded-full"
            style={{ background: "linear-gradient(90deg, #93C5FD, #60A5FA)" }}
          />
        </div>
        <p className="text-xs text-blue-400 font-medium mt-1">{Math.round(pct)}% of daily goal</p>
      </Card>

      {/* Quick Add Buttons */}
      <Card className="mb-4">
        <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">Quick Add</p>
        <div className="flex gap-2 flex-wrap">
          {QUICK_AMOUNTS.map((amt, i) => (
            <motion.button
              key={amt}
              whileTap={{ scale: 0.92 }}
              onClick={() => addWater(amt)}
              className="flex flex-col items-center gap-1 px-3 py-2.5 rounded-2xl bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-900/30 text-blue-600 dark:text-blue-300 active:bg-blue-100 transition-colors"
            >
              <span className="text-lg">{QUICK_LABELS[i].split(" ")[0]}</span>
              <span className="text-xs font-bold">{amt}ml</span>
              <span className="text-[9px] text-blue-400">{QUICK_LABELS[i].split(" ").slice(1).join(" ")}</span>
            </motion.button>
          ))}
          <motion.button
            whileTap={{ scale: 0.92 }}
            onClick={() => setShowCustom(!showCustom)}
            className="flex flex-col items-center gap-1 px-3 py-2.5 rounded-2xl border-2 border-dashed border-blue-200 dark:border-blue-800 text-blue-400"
          >
            <Plus size={20} />
            <span className="text-xs font-bold">Custom</span>
          </motion.button>
        </div>

        <AnimatePresence>
          {showCustom && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="flex gap-2 mt-3">
                <div className="flex-1 relative">
                  <input
                    value={customAmount}
                    onChange={e => setCustomAmount(e.target.value)}
                    placeholder="Amount in ml"
                    className="input-glow w-full"
                    type="number"
                    inputMode="numeric"
                  />
                </div>
                <button onClick={addCustom} className="btn-primary px-5">Add</button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </Card>

      {/* Weekly Chart */}
      {weekData.some(d => d > 0) && (
        <Card className="mb-4">
          <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">This Week</p>
          <div className="h-32">
            <Bar
              data={{
                labels: weekLabels,
                datasets: [{
                  data: weekData,
                  backgroundColor: weekData.map((d, i) =>
                    i === 6
                      ? "rgba(96, 165, 250, 0.9)"
                      : d >= waterGoal
                      ? "rgba(52, 211, 153, 0.7)"
                      : "rgba(147, 197, 253, 0.5)"
                  ),
                  borderRadius: 8,
                }],
              }}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false }, tooltip: {
                  callbacks: {
                    label: ctx => ` ${formatWater(ctx.raw as number)}`,
                  }
                }},
                scales: {
                  x: { grid: { display: false }, ticks: { font: { size: 10 }, color: "#9CA3AF" } },
                  y: {
                    display: true,
                    grid: { color: "rgba(0,0,0,0.04)" },
                    ticks: { font: { size: 9 }, color: "#9CA3AF", callback: v => formatWater(v as number) },
                  },
                },
              }}
            />
          </div>
          <div className="flex items-center gap-3 mt-2 text-xs text-gray-400">
            <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm bg-emerald-300 inline-block" /> Goal met</span>
            <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm bg-blue-200 inline-block" /> Under goal</span>
          </div>
        </Card>
      )}

      {/* Today's Log */}
      {logs.length > 0 && (
        <Card>
          <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">Today's Log</p>
          <div className="space-y-2">
            <AnimatePresence>
              {logs.map(log => (
                <motion.div
                  key={log.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 10 }}
                  className="flex items-center gap-3 p-2.5 rounded-xl bg-blue-50/50 dark:bg-blue-900/10"
                >
                  <Droplets size={16} className="text-blue-400" />
                  <div className="flex-1">
                    <p className="text-sm font-semibold">{log.amount}ml</p>
                    <p className="text-xs text-gray-400">{format(new Date(log.createdAt), "h:mm a")}</p>
                  </div>
                  <button
                    onClick={() => log.id && removeLog(log.id)}
                    className="w-7 h-7 rounded-lg bg-red-50 dark:bg-red-900/20 flex items-center justify-center"
                  >
                    <Trash2 size={13} className="text-red-400" />
                  </button>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </Card>
      )}
    </div>
  );
}

function WaterBottle({ pct }: { pct: number }) {
  return (
    <svg width="80" height="160" viewBox="0 0 80 160">
      {/* Bottle outline */}
      <defs>
        <clipPath id="bottle-clip">
          <path d="M22 30 Q18 35 16 45 L10 70 Q8 80 8 95 L8 130 Q8 145 20 148 L60 148 Q72 145 72 130 L72 95 Q72 80 70 70 L64 45 Q62 35 58 30 Z" />
        </clipPath>
        <linearGradient id="water-grad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#93C5FD" />
          <stop offset="100%" stopColor="#60A5FA" />
        </linearGradient>
      </defs>

      {/* Bottle body */}
      <path
        d="M22 30 Q18 35 16 45 L10 70 Q8 80 8 95 L8 130 Q8 145 20 148 L60 148 Q72 145 72 130 L72 95 Q72 80 70 70 L64 45 Q62 35 58 30 Z"
        fill="rgba(219,234,254,0.3)"
        stroke="rgba(147,197,253,0.5)"
        strokeWidth="1.5"
      />

      {/* Water fill */}
      <motion.rect
        x="8"
        y={148 - ((148 - 30) * pct / 100)}
        width="64"
        height={(148 - 30) * pct / 100}
        fill="url(#water-grad)"
        clipPath="url(#bottle-clip)"
        opacity="0.7"
        animate={{ y: 148 - ((148 - 30) * pct / 100), height: (148 - 30) * pct / 100 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      />

      {/* Wave effect */}
      {pct > 0 && pct < 100 && (
        <motion.path
          d={`M8 ${148 - ((148 - 30) * pct / 100)} Q24 ${148 - ((148 - 30) * pct / 100) - 4} 40 ${148 - ((148 - 30) * pct / 100)} Q56 ${148 - ((148 - 30) * pct / 100) + 4} 72 ${148 - ((148 - 30) * pct / 100)}`}
          fill="none"
          stroke="rgba(147,197,253,0.8)"
          strokeWidth="2"
          clipPath="url(#bottle-clip)"
          animate={{ d: [`M8 ${148 - ((148 - 30) * pct / 100)} Q24 ${148 - ((148 - 30) * pct / 100) - 5} 40 ${148 - ((148 - 30) * pct / 100)} Q56 ${148 - ((148 - 30) * pct / 100) + 5} 72 ${148 - ((148 - 30) * pct / 100)}`,
            `M8 ${148 - ((148 - 30) * pct / 100)} Q24 ${148 - ((148 - 30) * pct / 100) + 5} 40 ${148 - ((148 - 30) * pct / 100)} Q56 ${148 - ((148 - 30) * pct / 100) - 5} 72 ${148 - ((148 - 30) * pct / 100)}`] }}
          transition={{ duration: 2, repeat: Infinity, repeatType: "reverse", ease: "easeInOut" }}
        />
      )}

      {/* Bottle cap */}
      <rect x="28" y="18" width="24" height="14" rx="4" fill="rgba(147,197,253,0.6)" />
      <rect x="32" y="10" width="16" height="10" rx="3" fill="rgba(96,165,250,0.8)" />

      {/* Shine effect */}
      <line x1="18" y1="60" x2="18" y2="120" stroke="rgba(255,255,255,0.4)" strokeWidth="3" strokeLinecap="round" />

      {/* Percentage label in bottle */}
      {pct > 15 && (
        <text
          x="40"
          y={148 - ((148 - 30) * pct / 100) + 20}
          textAnchor="middle"
          fill="white"
          fontSize="13"
          fontWeight="700"
          fontFamily="system-ui"
        >
          {Math.round(pct)}%
        </text>
      )}
    </svg>
  );
}
