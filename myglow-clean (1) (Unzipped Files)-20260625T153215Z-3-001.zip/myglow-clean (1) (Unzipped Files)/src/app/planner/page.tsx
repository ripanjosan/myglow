"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, X, Check, Sunrise, Sun, Moon, Calendar } from "lucide-react";
import PageHeader from "@/components/layout/PageHeader";
import Card from "@/components/ui/Card";
import { db, PlannerItem, getTodayString } from "@/lib/db";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

type Priority = "low" | "medium" | "high";
type Category = "health" | "nutrition" | "fitness" | "mindfulness" | "personal" | "work";

const CATEGORIES: Record<Category, { emoji: string; color: string }> = {
  health: { emoji: "💊", color: "#F9C6D0" },
  nutrition: { emoji: "🥗", color: "#34D399" },
  fitness: { emoji: "💪", color: "#60A5FA" },
  mindfulness: { emoji: "🧘", color: "#C8B6E2" },
  personal: { emoji: "💝", color: "#FCD34D" },
  work: { emoji: "💼", color: "#FB923C" },
};

const DEFAULT_ROUTINE = [
  { time: "6:30 AM", title: "Wake up & Morning Routine", category: "health" as Category, priority: "high" as Priority },
  { time: "7:00 AM", title: "Morning Journal & Affirmations", category: "mindfulness" as Category, priority: "medium" as Priority },
  { time: "7:30 AM", title: "Healthy Breakfast", category: "nutrition" as Category, priority: "high" as Priority },
  { time: "8:00 AM", title: "Drink 2 glasses of water", category: "health" as Category, priority: "high" as Priority },
  { time: "12:00 PM", title: "Healthy Lunch", category: "nutrition" as Category, priority: "high" as Priority },
  { time: "1:00 PM", title: "Post-lunch walk", category: "fitness" as Category, priority: "medium" as Priority },
  { time: "5:00 PM", title: "Workout / Exercise", category: "fitness" as Category, priority: "high" as Priority },
  { time: "7:30 PM", title: "Healthy Dinner", category: "nutrition" as Category, priority: "high" as Priority },
  { time: "9:00 PM", title: "Evening journaling", category: "mindfulness" as Category, priority: "medium" as Priority },
  { time: "10:00 PM", title: "Wind down, no screens", category: "health" as Category, priority: "medium" as Priority },
  { time: "10:30 PM", title: "Sleep", category: "health" as Category, priority: "high" as Priority },
];

type TimeBlock = "morning" | "afternoon" | "evening";

export default function PlannerPage() {
  const [items, setItems] = useState<PlannerItem[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [newItem, setNewItem] = useState({
    time: "", title: "", category: "personal" as Category, priority: "medium" as Priority
  });
  const [activeBlock, setActiveBlock] = useState<TimeBlock>("morning");
  const today = getTodayString();

  useEffect(() => { loadData(); }, []);

  async function loadData() {
    let todayItems = await db.plannerItems.where("date").equals(today).sortBy("time");
    if (todayItems.length === 0) {
      // Seed default routine for today
      await db.plannerItems.bulkAdd(DEFAULT_ROUTINE.map(item => ({
        ...item, date: today, description: "", completed: false, createdAt: Date.now()
      })) as PlannerItem[]);
      todayItems = await db.plannerItems.where("date").equals(today).sortBy("time");
    }
    setItems(todayItems);
  }

  async function toggleItem(id: number, completed: boolean) {
    await db.plannerItems.update(id, { completed: !completed });
    await loadData();
  }

  async function deleteItem(id: number) {
    await db.plannerItems.delete(id);
    await loadData();
  }

  async function addItem() {
    if (!newItem.title.trim()) return;
    await db.plannerItems.add({
      ...newItem,
      date: today,
      description: "",
      completed: false,
      createdAt: Date.now(),
    } as PlannerItem);
    setNewItem({ time: "", title: "", category: "personal", priority: "medium" });
    setShowAdd(false);
    await loadData();
  }

  const getTimeBlock = (time?: string): TimeBlock => {
    if (!time) return "morning";
    const hour = parseInt(time.split(":")[0]);
    const isPM = time.includes("PM");
    const h24 = isPM && hour !== 12 ? hour + 12 : (!isPM && hour === 12 ? 0 : hour);
    if (h24 < 12) return "morning";
    if (h24 < 17) return "afternoon";
    return "evening";
  };

  const blocks: Record<TimeBlock, { label: string; emoji: string; icon: React.ReactNode }> = {
    morning: { label: "Morning", emoji: "🌅", icon: <Sunrise size={14} /> },
    afternoon: { label: "Afternoon", emoji: "☀️", icon: <Sun size={14} /> },
    evening: { label: "Evening", emoji: "🌙", icon: <Moon size={14} /> },
  };

  const filteredItems = items.filter(i => getTimeBlock(i.time) === activeBlock);
  const completedCount = items.filter(i => i.completed).length;
  const completionPct = items.length > 0 ? Math.round((completedCount / items.length) * 100) : 0;

  return (
    <div className="page-container">
      <PageHeader
        title="Planner"
        emoji="📅"
        subtitle={format(new Date(), "EEEE, MMMM d")}
        rightElement={
          <button onClick={() => setShowAdd(true)} className="btn-primary py-2 px-4 text-xs">
            <Plus size={14} /> Add
          </button>
        }
      />

      {/* Progress */}
      <Card className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <div>
            <p className="text-xs text-gray-400">Today's Routine</p>
            <p className="font-display text-2xl font-bold">
              <span className="text-gradient">{completedCount}</span>
              <span className="text-gray-300 text-lg"> / {items.length}</span>
            </p>
          </div>
          <div className="text-right">
            <p className="font-bold text-2xl text-gradient">{completionPct}%</p>
            <p className="text-xs text-gray-400">complete</p>
          </div>
        </div>
        <div className="h-2.5 rounded-full bg-gray-100 dark:bg-gray-800 overflow-hidden">
          <motion.div
            animate={{ width: `${completionPct}%` }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="h-full rounded-full bg-gradient-to-r from-glow-pink to-glow-lavender"
          />
        </div>
        {completionPct === 100 && (
          <p className="text-center text-xs text-emerald-500 font-semibold mt-2">🎉 Perfect day! You're glowing! ✨</p>
        )}
      </Card>

      {/* Time Block Tabs */}
      <div className="flex gap-2 mb-4">
        {(Object.keys(blocks) as TimeBlock[]).map(block => (
          <button
            key={block}
            onClick={() => setActiveBlock(block)}
            className={cn(
              "flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-2xl text-sm font-semibold transition-all",
              activeBlock === block
                ? "bg-gradient-to-r from-glow-pink to-glow-lavender text-purple-900 shadow-glow"
                : "glass text-gray-500"
            )}
          >
            {blocks[block].emoji}
            <span className="hidden xs:inline">{blocks[block].label}</span>
          </button>
        ))}
      </div>

      {/* Items */}
      <div className="space-y-2.5">
        <AnimatePresence>
          {filteredItems.length === 0 ? (
            <Card>
              <div className="text-center py-8">
                <p className="text-3xl mb-2">{blocks[activeBlock].emoji}</p>
                <p className="text-sm text-gray-400">No items for {blocks[activeBlock].label.toLowerCase()}</p>
                <button onClick={() => setShowAdd(true)} className="mt-2 text-xs text-glow-rose font-medium">
                  + Add item
                </button>
              </div>
            </Card>
          ) : (
            filteredItems.map((item, i) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ delay: i * 0.04 }}
              >
                <div className={cn(
                  "glass-card p-4 flex items-center gap-3 transition-all duration-300",
                  item.completed && "opacity-60"
                )}>
                  {/* Check Button */}
                  <motion.button
                    whileTap={{ scale: 0.85 }}
                    onClick={() => toggleItem(item.id!, item.completed)}
                    className={cn(
                      "w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 transition-all duration-300",
                      item.completed
                        ? "bg-gradient-to-br from-glow-pink to-glow-lavender shadow-glow"
                        : "border-2 border-gray-200 dark:border-gray-700"
                    )}
                  >
                    {item.completed && <Check size={16} className="text-white" strokeWidth={2.5} />}
                  </motion.button>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span>{CATEGORIES[item.category]?.emoji}</span>
                      <p className={cn("text-sm font-semibold truncate", item.completed && "line-through text-gray-400")}>
                        {item.title}
                      </p>
                    </div>
                    {item.time && (
                      <p className="text-xs text-gray-400 mt-0.5">⏰ {item.time}</p>
                    )}
                  </div>

                  {/* Priority + Delete */}
                  <div className="flex items-center gap-1.5">
                    <div
                      className="w-2 h-2 rounded-full"
                      style={{
                        background: item.priority === "high" ? "#EF4444" : item.priority === "medium" ? "#FBBF24" : "#34D399"
                      }}
                    />
                    <button
                      onClick={() => deleteItem(item.id!)}
                      className="w-7 h-7 rounded-lg bg-gray-50 dark:bg-dark-surface flex items-center justify-center opacity-40 hover:opacity-100"
                    >
                      <X size={13} className="text-gray-400" />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>

      {/* Add Item Modal */}
      <AnimatePresence>
        {showAdd && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-end"
            onClick={e => { if (e.target === e.currentTarget) setShowAdd(false); }}
          >
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="w-full max-w-md mx-auto glass rounded-t-3xl p-5"
            >
              <div className="flex items-center justify-between mb-5">
                <h2 className="font-display text-lg font-bold">Add Item</h2>
                <button onClick={() => setShowAdd(false)} className="w-8 h-8 rounded-full bg-gray-100 dark:bg-dark-surface flex items-center justify-center">
                  <X size={16} />
                </button>
              </div>
              <div className="space-y-3">
                <input
                  value={newItem.title}
                  onChange={e => setNewItem(p => ({ ...p, title: e.target.value }))}
                  className="input-glow w-full"
                  placeholder="What do you need to do?"
                  autoFocus
                />
                <input
                  value={newItem.time}
                  onChange={e => setNewItem(p => ({ ...p, time: e.target.value }))}
                  className="input-glow w-full"
                  placeholder="Time (e.g. 7:00 AM)"
                />
                <div className="grid grid-cols-3 gap-2">
                  {(Object.keys(CATEGORIES) as Category[]).map(cat => (
                    <button
                      key={cat}
                      onClick={() => setNewItem(p => ({ ...p, category: cat }))}
                      className={cn(
                        "p-2.5 rounded-xl text-xs font-medium transition-all",
                        newItem.category === cat ? "shadow-glow scale-105" : "glass text-gray-500"
                      )}
                      style={newItem.category === cat ? { background: `${CATEGORIES[cat].color}30` } : {}}
                    >
                      {CATEGORIES[cat].emoji} {cat}
                    </button>
                  ))}
                </div>
                <div className="flex gap-2">
                  {(["low", "medium", "high"] as Priority[]).map(p => (
                    <button
                      key={p}
                      onClick={() => setNewItem(prev => ({ ...prev, priority: p }))}
                      className={cn(
                        "flex-1 py-2 rounded-xl text-xs font-semibold transition-all capitalize",
                        newItem.priority === p ? "shadow-md" : "glass text-gray-400"
                      )}
                      style={newItem.priority === p ? {
                        background: p === "high" ? "#EF444420" : p === "medium" ? "#FBBF2420" : "#34D39920",
                        color: p === "high" ? "#EF4444" : p === "medium" ? "#F59E0B" : "#10B981",
                      } : {}}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex gap-3 mt-5">
                <button onClick={() => setShowAdd(false)} className="flex-1 btn-ghost border border-gray-200 dark:border-dark-border py-3">Cancel</button>
                <button onClick={addItem} className="flex-1 btn-primary py-3">Add to Planner</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
