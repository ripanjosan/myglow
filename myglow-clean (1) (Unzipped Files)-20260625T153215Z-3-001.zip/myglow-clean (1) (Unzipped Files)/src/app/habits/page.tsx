"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, X, Flame, Check, Edit2 } from "lucide-react";
import PageHeader from "@/components/layout/PageHeader";
import Card from "@/components/ui/Card";
import { db, HabitDefinition, HabitLog, getTodayString, seedDatabase } from "@/lib/db";
import { getStreakCount } from "@/lib/utils";
import { format, subDays } from "date-fns";

const EMOJI_OPTIONS = ["💧", "🏋️", "🥗", "📓", "🧘", "😴", "🚶", "🚫", "📚", "🎯", "💪", "🌿", "🧘‍♀️", "🍎", "☀️", "🏃", "💊", "🙏"];
const COLOR_OPTIONS = ["#F9C6D0", "#C8B6E2", "#60A5FA", "#34D399", "#FBBF24", "#F87171", "#A78BFA", "#FB923C"];

export default function HabitsPage() {
  const [habits, setHabits] = useState<HabitDefinition[]>([]);
  const [todayLogs, setTodayLogs] = useState<HabitLog[]>([]);
  const [streaks, setStreaks] = useState<Record<number, number>>({});
  const [showAdd, setShowAdd] = useState(false);
  const [newHabit, setNewHabit] = useState({ name: "", icon: "✅", color: "#F9C6D0" });
  const today = getTodayString();

  useEffect(() => {
    seedDatabase().then(loadData);
  }, []);

  async function loadData() {
    const allHabits = await db.habitDefinitions.where("isActive").equals(1).toArray();
    setHabits(allHabits);

    const logs = await db.habitLogs.where("date").equals(today).toArray();
    setTodayLogs(logs);

    // Calculate streaks
    const allLogs = await db.habitLogs.toArray();
    const streakMap: Record<number, number> = {};
    for (const habit of allHabits) {
      const hLogs = allLogs.filter(l => l.habitId === habit.id && l.completed);
      streakMap[habit.id!] = getStreakCount(hLogs);
    }
    setStreaks(streakMap);
  }

  async function toggleHabit(habitId: number) {
    const existing = todayLogs.find(l => l.habitId === habitId);
    if (existing?.id) {
      await db.habitLogs.update(existing.id, { completed: !existing.completed });
    } else {
      await db.habitLogs.add({
        habitId, date: today, completed: true, createdAt: Date.now()
      });
    }
    await loadData();
  }

  async function addHabit() {
    if (!newHabit.name.trim()) return;
    await db.habitDefinitions.add({
      name: newHabit.name,
      icon: newHabit.icon,
      color: newHabit.color,
      targetDays: [0, 1, 2, 3, 4, 5, 6],
      isActive: true,
      createdAt: Date.now(),
    });
    setNewHabit({ name: "", icon: "✅", color: "#F9C6D0" });
    setShowAdd(false);
    await loadData();
  }

  async function deleteHabit(id: number) {
    await db.habitDefinitions.update(id, { isActive: false });
    await loadData();
  }

  const completedCount = todayLogs.filter(l => l.completed).length;
  const completionPct = habits.length > 0 ? Math.round((completedCount / habits.length) * 100) : 0;

  // Last 7 days for habit overview
  const last7 = Array.from({ length: 7 }, (_, i) => subDays(new Date(), 6 - i));

  return (
    <div className="page-container">
      <PageHeader
        title="Habits"
        emoji="✅"
        subtitle="Build your glow routine"
        rightElement={
          <button onClick={() => setShowAdd(true)} className="btn-primary py-2 px-4 text-xs">
            <Plus size={14} /> New
          </button>
        }
      />

      {/* Today's Progress */}
      <Card className="mb-4">
        <div className="flex items-center justify-between mb-3">
          <div>
            <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider">Today's Progress</p>
            <p className="font-display text-2xl font-bold mt-0.5">
              <span className="text-gradient">{completedCount}</span>
              <span className="text-gray-300 text-lg"> / {habits.length}</span>
            </p>
          </div>
          <div className="relative w-16 h-16">
            <svg className="w-16 h-16 -rotate-90" viewBox="0 0 64 64">
              <circle cx="32" cy="32" r="26" fill="none" stroke="rgba(249,198,208,0.12)" strokeWidth="6" />
              <motion.circle
                cx="32" cy="32" r="26"
                fill="none"
                stroke="url(#habit-grad)"
                strokeWidth="6"
                strokeLinecap="round"
                strokeDasharray={2 * Math.PI * 26}
                initial={{ strokeDashoffset: 2 * Math.PI * 26 }}
                animate={{ strokeDashoffset: 2 * Math.PI * 26 * (1 - completionPct / 100) }}
                transition={{ duration: 1, ease: "easeOut" }}
              />
              <defs>
                <linearGradient id="habit-grad" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#F9C6D0" />
                  <stop offset="100%" stopColor="#C8B6E2" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-xs font-bold text-gradient">{completionPct}%</span>
            </div>
          </div>
        </div>

        {completionPct === 100 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-gradient-to-r from-glow-pink/20 to-glow-lavender/20 rounded-2xl p-3 text-center"
          >
            <p className="text-sm font-semibold">🎉 All habits complete! You're glowing today! ✨</p>
          </motion.div>
        )}
      </Card>

      {/* Habits List */}
      <div className="space-y-2.5 mb-4">
        <AnimatePresence>
          {habits.map((habit, i) => {
            const log = todayLogs.find(l => l.habitId === habit.id);
            const done = log?.completed ?? false;
            const streak = streaks[habit.id!] || 0;

            return (
              <motion.div
                key={habit.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ delay: i * 0.05 }}
              >
                <div className={`glass-card p-4 transition-all duration-300 ${done ? "border-glow-pink/40" : ""}`}>
                  <div className="flex items-center gap-3">
                    {/* Completion Button */}
                    <motion.button
                      whileTap={{ scale: 0.85 }}
                      onClick={() => toggleHabit(habit.id!)}
                      className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 transition-all duration-300 ${
                        done
                          ? "shadow-glow"
                          : "border-2 border-gray-200 dark:border-gray-700"
                      }`}
                      style={done ? { background: `linear-gradient(135deg, ${habit.color}, ${habit.color}88)` } : {}}
                    >
                      {done ? (
                        <Check size={18} className="text-white" strokeWidth={2.5} />
                      ) : (
                        <span className="text-xl">{habit.icon}</span>
                      )}
                    </motion.button>

                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        {!done && <span className="text-base">{habit.icon}</span>}
                        <p className={`text-sm font-semibold ${done ? "line-through text-gray-400" : ""}`}>
                          {habit.name}
                        </p>
                      </div>
                      {streak > 0 && (
                        <div className="flex items-center gap-1 mt-0.5">
                          <Flame size={12} className="text-orange-400" />
                          <span className="text-xs font-medium text-orange-400">{streak} day streak</span>
                        </div>
                      )}
                    </div>

                    <button
                      onClick={() => deleteHabit(habit.id!)}
                      className="w-7 h-7 rounded-lg bg-gray-50 dark:bg-dark-surface flex items-center justify-center opacity-50 hover:opacity-100"
                    >
                      <X size={13} className="text-gray-400" />
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* Weekly Overview Table */}
      {habits.length > 0 && <WeeklyHabitGrid habits={habits} last7={last7} today={today} />}

      {/* Add Habit Modal */}
      <AnimatePresence>
        {showAdd && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-end"
            onClick={e => { if (e.target === e.currentTarget) setShowAdd(false); }}
          >
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="w-full max-w-md mx-auto glass rounded-t-3xl p-5"
            >
              <div className="flex items-center justify-between mb-5">
                <h2 className="font-display text-lg font-bold">New Habit</h2>
                <button onClick={() => setShowAdd(false)} className="w-8 h-8 rounded-full bg-gray-100 dark:bg-dark-surface flex items-center justify-center">
                  <X size={16} />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-xs font-medium text-gray-500 block mb-1.5">Habit Name</label>
                  <input
                    value={newHabit.name}
                    onChange={e => setNewHabit(p => ({ ...p, name: e.target.value }))}
                    className="input-glow w-full"
                    placeholder="e.g. Drink 2L water"
                    autoFocus
                  />
                </div>

                <div>
                  <label className="text-xs font-medium text-gray-500 block mb-1.5">Choose Icon</label>
                  <div className="flex flex-wrap gap-2">
                    {EMOJI_OPTIONS.map(emoji => (
                      <button
                        key={emoji}
                        onClick={() => setNewHabit(p => ({ ...p, icon: emoji }))}
                        className={`w-10 h-10 rounded-xl text-xl flex items-center justify-center transition-all ${
                          newHabit.icon === emoji ? "bg-glow-pink/30 scale-110 shadow-glow" : "bg-gray-50 dark:bg-dark-surface"
                        }`}
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-xs font-medium text-gray-500 block mb-1.5">Color</label>
                  <div className="flex gap-2">
                    {COLOR_OPTIONS.map(color => (
                      <button
                        key={color}
                        onClick={() => setNewHabit(p => ({ ...p, color }))}
                        className={`w-8 h-8 rounded-full transition-all ${
                          newHabit.color === color ? "scale-125 shadow-md" : ""
                        }`}
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex gap-3 mt-5">
                <button onClick={() => setShowAdd(false)} className="flex-1 btn-ghost border border-gray-200 dark:border-dark-border py-3">Cancel</button>
                <button onClick={addHabit} className="flex-1 btn-primary py-3">Add Habit</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function WeeklyHabitGrid({ habits, last7, today }: { habits: HabitDefinition[]; last7: Date[]; today: string }) {
  const [logs, setLogs] = useState<HabitLog[]>([]);

  useEffect(() => {
    async function load() {
      const dates = last7.map(d => d.toISOString().split("T")[0]);
      const allLogs = await db.habitLogs.where("date").anyOf(dates).toArray();
      setLogs(allLogs);
    }
    load();
  }, []);

  return (
    <Card className="mb-4">
      <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">Last 7 Days</p>
      <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr>
              <th className="text-left text-gray-400 font-medium pb-2 pr-2 w-28">Habit</th>
              {last7.map((d, i) => (
                <th key={i} className={`text-center pb-2 font-medium ${d.toISOString().split("T")[0] === today ? "text-glow-rose" : "text-gray-400"}`}>
                  {format(d, "E")[0]}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {habits.slice(0, 6).map(habit => (
              <tr key={habit.id}>
                <td className="pr-2 py-1 text-gray-600 dark:text-gray-400 truncate max-w-[100px]">
                  {habit.icon} {habit.name.split(" ")[0]}
                </td>
                {last7.map((d, i) => {
                  const dateStr = d.toISOString().split("T")[0];
                  const log = logs.find(l => l.habitId === habit.id && l.date === dateStr);
                  const done = log?.completed ?? false;
                  return (
                    <td key={i} className="text-center py-1">
                      <div
                        className="w-6 h-6 rounded-lg mx-auto flex items-center justify-center"
                        style={done ? { background: `${habit.color}40` } : {}}
                      >
                        {done ? (
                          <Check size={12} style={{ color: habit.color }} strokeWidth={2.5} />
                        ) : (
                          <span className="text-gray-200 dark:text-gray-700">·</span>
                        )}
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
