"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Moon, Sun, Heart, Zap, Star, Plus, X, Flame } from "lucide-react";
import PageHeader from "@/components/layout/PageHeader";
import Card from "@/components/ui/Card";
import { db, JournalEntry, getTodayString } from "@/lib/db";
import { format } from "date-fns";
import { getStreakCount } from "@/lib/utils";

type Tab = "morning" | "night" | "gratitude" | "369" | "affirmations";

const TABS: { id: Tab; label: string; icon: React.ReactNode; description: string }[] = [
  { id: "morning", label: "Morning", icon: <Sun size={16} />, description: "Set intentions for the day" },
  { id: "night", label: "Night", icon: <Moon size={16} />, description: "Reflect on your day" },
  { id: "gratitude", label: "Gratitude", icon: <Heart size={16} />, description: "3 things you're grateful for" },
  { id: "369", label: "3-6-9", icon: <Zap size={16} />, description: "The manifestation method" },
  { id: "affirmations", label: "Affirm", icon: <Star size={16} />, description: "Speak your truth" },
];

const AFFIRMATION_PROMPTS = [
  "I am worthy of love and abundance.",
  "I am becoming the healthiest version of myself.",
  "I am grateful for my body and all it does for me.",
  "I attract positive energy and joy.",
  "I am strong, capable, and radiant.",
  "I love and accept myself completely.",
  "I am aligned with my highest purpose.",
  "Health and vitality flow through me naturally.",
  "I am deserving of all the good things in life.",
  "My body is my home, and I treat it with love.",
];

const MORNING_PROMPTS = [
  "What is your main intention for today?",
  "What are you most excited about today?",
  "How do you want to feel by the end of the day?",
  "What is one thing you will do to nourish yourself today?",
];

const NIGHT_PROMPTS = [
  "What went well today?",
  "What made you smile today?",
  "What did you learn about yourself today?",
  "What are you releasing before sleep?",
];

export default function ManifestationPage() {
  const [activeTab, setActiveTab] = useState<Tab>("morning");
  const [entries, setEntries] = useState<Record<string, JournalEntry | undefined>>({});
  const [content, setContent] = useState("");
  const [gratitudeItems, setGratitudeItems] = useState(["", "", ""]);
  const [method369, setMethod369] = useState({ desire: "", morning: "", afternoon: "", night: "" });
  const [affirmations, setAffirmations] = useState<string[]>(AFFIRMATION_PROMPTS.slice(0, 5));
  const [streak, setStreak] = useState(0);
  const [saved, setSaved] = useState(false);
  const today = getTodayString();

  useEffect(() => { loadData(); }, []);

  async function loadData() {
    const allEntries = await db.journalEntries.where("date").equals(today).toArray();
    const map: Record<string, JournalEntry> = {};
    allEntries.forEach(e => { map[e.type] = e; });

    setEntries(map);

    const tab = activeTab;
    if (map[tab]) {
      setContent(map[tab]?.content || "");
      setGratitudeItems(map["gratitude"]?.gratitudeItems || ["", "", ""]);
    }

    const allLogs = await db.journalEntries.toArray();
    const uniqueDates = [...new Set(allLogs.map(e => e.date))].map(d => ({ date: d, completed: true }));
    setStreak(getStreakCount(uniqueDates));
  }

  async function saveEntry() {
    let entryData: Partial<JournalEntry> = {
      date: today,
      type: activeTab,
      content,
      createdAt: Date.now(),
    };

    if (activeTab === "gratitude") {
      entryData.gratitudeItems = gratitudeItems.filter(Boolean);
      entryData.content = gratitudeItems.filter(Boolean).join("\n");
    }

    if (activeTab === "369") {
      entryData.content = method369.desire;
    }

    if (activeTab === "affirmations") {
      entryData.affirmations = affirmations;
      entryData.content = affirmations.join("\n");
    }

    const existing = entries[activeTab];
    if (existing?.id) {
      await db.journalEntries.update(existing.id, entryData);
    } else {
      await db.journalEntries.add(entryData as JournalEntry);
    }
    setSaved(true);
    await loadData();
  }

  const tabContent = () => {
    switch (activeTab) {
      case "morning":
        return (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-50 to-yellow-50 dark:from-amber-900/10 dark:to-yellow-900/10">
              <p className="text-xs font-semibold text-amber-600 dark:text-amber-400 uppercase tracking-wider mb-1">Prompt</p>
              <p className="text-sm text-amber-700 dark:text-amber-300 italic">
                {MORNING_PROMPTS[new Date().getDay() % MORNING_PROMPTS.length]}
              </p>
            </div>
            <textarea
              value={content}
              onChange={e => { setContent(e.target.value); setSaved(false); }}
              placeholder="Write your morning intentions..."
              className="input-glow w-full min-h-[160px] resize-none"
            />
          </div>
        );

      case "night":
        return (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-900/10 dark:to-purple-900/10">
              <p className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider mb-1">Reflection Prompt</p>
              <p className="text-sm text-indigo-700 dark:text-indigo-300 italic">
                {NIGHT_PROMPTS[new Date().getDay() % NIGHT_PROMPTS.length]}
              </p>
            </div>
            <textarea
              value={content}
              onChange={e => { setContent(e.target.value); setSaved(false); }}
              placeholder="Reflect on your day..."
              className="input-glow w-full min-h-[160px] resize-none"
            />
          </div>
        );

      case "gratitude":
        return (
          <div className="space-y-4">
            <p className="text-sm text-gray-500 dark:text-gray-400 italic text-center">
              "Gratitude turns what we have into enough." 💖
            </p>
            <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider">Today I am grateful for...</p>
            {gratitudeItems.map((item, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="w-7 h-7 rounded-full bg-gradient-to-br from-glow-pink to-glow-lavender flex items-center justify-center flex-shrink-0">
                  <span className="text-white font-bold text-xs">{i + 1}</span>
                </div>
                <input
                  value={item}
                  onChange={e => {
                    const updated = [...gratitudeItems];
                    updated[i] = e.target.value;
                    setGratitudeItems(updated);
                    setSaved(false);
                  }}
                  placeholder={`Gratitude ${i + 1}...`}
                  className="input-glow flex-1"
                />
              </div>
            ))}
            {gratitudeItems.length < 10 && (
              <button
                onClick={() => { setGratitudeItems([...gratitudeItems, ""]); setSaved(false); }}
                className="w-full py-2 rounded-2xl border-2 border-dashed border-glow-pink/30 text-xs text-glow-rose font-medium"
              >
                + Add more gratitude
              </button>
            )}
          </div>
        );

      case "369":
        return (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-violet-50 to-purple-50 dark:from-violet-900/10 dark:to-purple-900/10">
              <p className="text-xs font-semibold text-violet-600 dark:text-violet-400 uppercase tracking-wider mb-1">The 369 Method</p>
              <p className="text-xs text-violet-700 dark:text-violet-300">
                Write your desire 3x in the morning, 6x in the afternoon, 9x at night. This is the manifestation method inspired by Nikola Tesla.
              </p>
            </div>

            <div>
              <label className="text-xs font-medium text-gray-500 block mb-1.5">Your Desire (what you're manifesting)</label>
              <textarea
                value={method369.desire}
                onChange={e => { setMethod369(p => ({ ...p, desire: e.target.value })); setSaved(false); }}
                placeholder="I am manifesting..."
                className="input-glow w-full min-h-[80px] resize-none"
              />
            </div>

            {method369.desire && (
              <>
                <Method369Section
                  title="Morning (3x)"
                  emoji="🌅"
                  content={method369.morning}
                  count={3}
                  desire={method369.desire}
                  onChange={v => { setMethod369(p => ({ ...p, morning: v })); setSaved(false); }}
                />
                <Method369Section
                  title="Afternoon (6x)"
                  emoji="☀️"
                  content={method369.afternoon}
                  count={6}
                  desire={method369.desire}
                  onChange={v => { setMethod369(p => ({ ...p, afternoon: v })); setSaved(false); }}
                />
                <Method369Section
                  title="Night (9x)"
                  emoji="🌙"
                  content={method369.night}
                  count={9}
                  desire={method369.desire}
                  onChange={v => { setMethod369(p => ({ ...p, night: v })); setSaved(false); }}
                />
              </>
            )}
          </div>
        );

      case "affirmations":
        return (
          <div className="space-y-3">
            <p className="text-xs text-gray-500 text-center italic">Speak these affirmations aloud with conviction ✨</p>
            {affirmations.map((aff, i) => (
              <div key={i} className="flex items-start gap-3 p-3 rounded-2xl bg-glow-blush/40 dark:bg-dark-surface/50">
                <span className="text-glow-gold text-sm font-bold mt-0.5">✦</span>
                <input
                  value={aff}
                  onChange={e => {
                    const updated = [...affirmations];
                    updated[i] = e.target.value;
                    setAffirmations(updated);
                    setSaved(false);
                  }}
                  className="flex-1 bg-transparent text-sm outline-none"
                />
                <button
                  onClick={() => { setAffirmations(affirmations.filter((_, j) => j !== i)); setSaved(false); }}
                  className="text-gray-300 hover:text-red-400"
                >
                  <X size={14} />
                </button>
              </div>
            ))}
            <button
              onClick={() => { setAffirmations([...affirmations, "I am..."]); setSaved(false); }}
              className="w-full py-3 rounded-2xl border-2 border-dashed border-glow-lavender/30 text-xs text-glow-rose font-medium"
            >
              + Add affirmation
            </button>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="page-container">
      <PageHeader
        title="Journal"
        emoji="✨"
        subtitle="Manifest your best life"
        rightElement={
          <div className="flex items-center gap-1.5 bg-orange-50 dark:bg-orange-900/20 px-3 py-1.5 rounded-xl">
            <Flame size={14} className="text-orange-400" />
            <span className="text-xs font-bold text-orange-500">{streak} days</span>
          </div>
        }
      />

      {/* Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 mb-4 scrollbar-hide">
        {TABS.map(tab => (
          <button
            key={tab.id}
            onClick={() => { setActiveTab(tab.id); setSaved(false); }}
            className={`flex-shrink-0 flex items-center gap-1.5 px-4 py-2 rounded-2xl text-sm font-semibold transition-all ${
              activeTab === tab.id
                ? "bg-gradient-to-r from-glow-pink to-glow-lavender text-purple-900 shadow-glow"
                : "glass text-gray-500"
            }`}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <Card className="mb-4">
        <div className="mb-4">
          <p className="text-sm font-bold">{TABS.find(t => t.id === activeTab)?.description}</p>
          <p className="text-xs text-gray-400">{format(new Date(), "EEEE, MMMM d")}</p>
        </div>
        {tabContent()}
      </Card>

      {/* Save */}
      <motion.button
        whileTap={{ scale: 0.97 }}
        onClick={saveEntry}
        className={`w-full py-4 rounded-2xl font-semibold text-sm transition-all duration-300 ${
          saved ? "bg-emerald-50 text-emerald-600 border border-emerald-200" : "btn-primary"
        }`}
      >
        {saved ? "✅ Saved!" : "Save Entry"}
      </motion.button>

      {/* Past Entries */}
      <PastEntries />
    </div>
  );
}

function Method369Section({ title, emoji, content, count, desire, onChange }: {
  title: string; emoji: string; content: string; count: number; desire: string; onChange: (v: string) => void;
}) {
  return (
    <div>
      <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider block mb-1.5">
        {emoji} {title}
      </label>
      <textarea
        value={content}
        onChange={e => onChange(e.target.value)}
        placeholder={`Write "${desire}" ${count} times...`}
        className="input-glow w-full resize-none"
        rows={Math.min(count + 1, 6)}
      />
      <p className="text-[9px] text-gray-400 mt-1">
        {content.split("\n").filter(l => l.trim()).length} / {count} times written
      </p>
    </div>
  );
}

function PastEntries() {
  const [recent, setRecent] = useState<JournalEntry[]>([]);

  useEffect(() => {
    db.journalEntries.orderBy("createdAt").reverse().limit(5).toArray().then(setRecent);
  }, []);

  if (!recent.length) return null;

  return (
    <Card className="mt-4">
      <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">Recent Entries</p>
      <div className="space-y-2">
        {recent.map(entry => (
          <div key={entry.id} className="p-3 rounded-xl bg-glow-blush/30 dark:bg-dark-surface/30">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-semibold capitalize text-glow-rose/70">{entry.type}</span>
              <span className="text-[9px] text-gray-400">{entry.date}</span>
            </div>
            <p className="text-xs text-gray-600 dark:text-gray-400 line-clamp-2">{entry.content}</p>
          </div>
        ))}
      </div>
    </Card>
  );
}
