"use client";

import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Plus, X, ChevronDown, Camera, Star, StarOff, Trash2, Edit2, Check } from "lucide-react";
import PageHeader from "@/components/layout/PageHeader";
import Card from "@/components/ui/Card";
import { MacroBar } from "@/components/ui/ProgressRing";
import { db, FoodItem, MealLog, getTodayNutrition, getTodayString, FOOD_DATABASE } from "@/lib/db";
import { cn } from "@/lib/utils";
import { format } from "date-fns";

type Meal = "breakfast" | "lunch" | "dinner" | "snacks";
const MEALS: { id: Meal; label: string; emoji: string; time: string }[] = [
  { id: "breakfast", label: "Breakfast", emoji: "🌅", time: "7–10 AM" },
  { id: "lunch", label: "Lunch", emoji: "☀️", time: "12–2 PM" },
  { id: "dinner", label: "Dinner", emoji: "🌙", time: "7–9 PM" },
  { id: "snacks", label: "Snacks", emoji: "🍎", time: "Any time" },
];

interface NutritionTotals {
  calories: number; protein: number; carbs: number; fat: number; fiber: number; sugar: number; sodium: number;
}

export default function NutritionPage() {
  const [activeMeal, setActiveMeal] = useState<Meal>("breakfast");
  const [search, setSearch] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [foods, setFoods] = useState<FoodItem[]>([]);
  const [filteredFoods, setFilteredFoods] = useState<FoodItem[]>([]);
  const [mealLogs, setMealLogs] = useState<Record<Meal, MealLog[]>>({ breakfast: [], lunch: [], dinner: [], snacks: [] });
  const [totals, setTotals] = useState<NutritionTotals>({ calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0, sugar: 0, sodium: 0 });
  const [calorieGoal, setCalorieGoal] = useState(1800);
  const [proteinGoal, setProteinGoal] = useState(100);
  const [showCustom, setShowCustom] = useState(false);
  const [servings, setServings] = useState<Record<number, number>>({});
  const today = getTodayString();

  useEffect(() => { loadData(); }, []);

  async function loadData() {
    const allFoods = await db.foods.toArray();
    setFoods(allFoods);
    setFilteredFoods(allFoods.slice(0, 20));

    const logs = await db.mealLogs.where("date").equals(today).toArray();
    const grouped = { breakfast: [], lunch: [], dinner: [], snacks: [] } as Record<Meal, MealLog[]>;
    logs.forEach(l => grouped[l.meal].push(l));
    setMealLogs(grouped);

    const t = await getTodayNutrition(today);
    setTotals(t);

    const cg = await db.settings.where("key").equals("calorieGoal").first();
    const pg = await db.settings.where("key").equals("proteinGoal").first();
    if (cg) setCalorieGoal(parseInt(cg.value));
    if (pg) setProteinGoal(parseInt(pg.value));
  }

  const handleSearch = useCallback((q: string) => {
    setSearch(q);
    if (!q.trim()) {
      setFilteredFoods(foods.slice(0, 20));
      return;
    }
    const lower = q.toLowerCase();
    const results = foods.filter(f =>
      f.name.toLowerCase().includes(lower) || f.category.toLowerCase().includes(lower)
    ).slice(0, 30);
    setFilteredFoods(results);
  }, [foods]);

  async function addFood(food: FoodItem) {
    const s = servings[food.id!] || 1;
    const log: Omit<MealLog, "id"> = {
      date: today,
      meal: activeMeal,
      foodId: food.id!,
      foodName: food.name,
      servings: s,
      calories: food.calories * s,
      protein: food.protein * s,
      carbs: food.carbs * s,
      fat: food.fat * s,
      fiber: food.fiber * s,
      sugar: food.sugar * s,
      sodium: food.sodium * s,
      createdAt: Date.now(),
    };
    await db.mealLogs.add(log as MealLog);
    await loadData();
    setShowSearch(false);
    setSearch("");
  }

  async function removeLog(id: number) {
    await db.mealLogs.delete(id);
    await loadData();
  }

  async function toggleFavorite(food: FoodItem) {
    if (food.id) {
      await db.foods.update(food.id, { isFavorite: !food.isFavorite });
      await loadData();
    }
  }

  const calRemaining = calorieGoal - totals.calories;
  const favFoods = foods.filter(f => f.isFavorite);

  return (
    <div className="page-container">
      <PageHeader title="Nutrition" emoji="🥗" subtitle="Track your daily nourishment" />

      {/* Calorie Budget */}
      <Card className="mb-4">
        <div className="flex justify-between items-center mb-3">
          <div>
            <p className="text-xs text-gray-400 font-medium">Calorie Budget</p>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="font-display text-3xl font-bold text-gradient">{Math.round(Math.max(0, calRemaining))}</span>
              <span className="text-sm text-gray-400">kcal remaining</span>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs text-gray-400">Consumed</p>
            <p className="text-lg font-bold">{Math.round(totals.calories)}</p>
            <p className="text-xs text-gray-400">/ {calorieGoal} kcal</p>
          </div>
        </div>
        <div className="h-2.5 rounded-full bg-gray-100 dark:bg-gray-800 overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${Math.min(100, (totals.calories / calorieGoal) * 100)}%` }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="h-full rounded-full"
            style={{
              background: totals.calories > calorieGoal
                ? "#EF4444"
                : "linear-gradient(90deg, #F9C6D0, #C8B6E2)",
            }}
          />
        </div>
        <div className="mt-4 space-y-2">
          <MacroBar label="Protein" value={totals.protein} max={proteinGoal} color="#C8B6E2" />
          <MacroBar label="Carbs" value={totals.carbs} max={calorieGoal * 0.5 / 4} color="#93C5FD" />
          <MacroBar label="Fat" value={totals.fat} max={calorieGoal * 0.3 / 9} color="#FCD34D" />
          <MacroBar label="Fiber" value={totals.fiber} max={25} color="#6EE7B7" />
        </div>
        <div className="flex gap-4 mt-3 pt-3 border-t border-glow-pink/10 text-xs text-gray-500">
          <span>Sugar: {Math.round(totals.sugar)}g</span>
          <span>Sodium: {Math.round(totals.sodium)}mg</span>
        </div>
      </Card>

      {/* Meal Tabs */}
      <div className="flex gap-2 mb-4 overflow-x-auto pb-1 scrollbar-hide">
        {MEALS.map(m => (
          <button
            key={m.id}
            onClick={() => setActiveMeal(m.id)}
            className={cn(
              "flex-shrink-0 flex items-center gap-1.5 px-4 py-2 rounded-2xl text-sm font-semibold transition-all",
              activeMeal === m.id
                ? "bg-gradient-to-r from-glow-pink to-glow-lavender text-purple-900 shadow-glow"
                : "glass text-gray-500 dark:text-gray-400"
            )}
          >
            <span>{m.emoji}</span>
            {m.label}
            {mealLogs[m.id].length > 0 && (
              <span className="w-5 h-5 rounded-full bg-white/50 text-[10px] font-bold flex items-center justify-center">
                {mealLogs[m.id].length}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Active Meal Logs */}
      <Card className="mb-4">
        <div className="flex items-center justify-between mb-3">
          <div>
            <p className="text-sm font-bold">{MEALS.find(m => m.id === activeMeal)?.label}</p>
            <p className="text-xs text-gray-400">
              {Math.round(mealLogs[activeMeal].reduce((a, l) => a + l.calories, 0))} kcal ·
              {Math.round(mealLogs[activeMeal].reduce((a, l) => a + l.protein, 0))}g protein
            </p>
          </div>
          <button
            onClick={() => setShowSearch(true)}
            className="btn-primary py-2 px-4 text-xs"
          >
            <Plus size={14} /> Add Food
          </button>
        </div>

        {mealLogs[activeMeal].length === 0 ? (
          <div className="text-center py-8">
            <p className="text-4xl mb-2">{MEALS.find(m => m.id === activeMeal)?.emoji}</p>
            <p className="text-sm text-gray-400">No food logged yet</p>
            <button onClick={() => setShowSearch(true)} className="mt-3 text-xs text-glow-rose font-medium">
              + Add your first item
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            <AnimatePresence>
              {mealLogs[activeMeal].map(log => (
                <motion.div
                  key={log.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 10 }}
                  className="flex items-center gap-3 p-2.5 rounded-xl bg-glow-blush/40 dark:bg-dark-surface/50"
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{log.foodName}</p>
                    <p className="text-xs text-gray-400">{log.servings} serving · {Math.round(log.protein)}g protein</p>
                  </div>
                  <p className="text-sm font-bold text-glow-rose">{Math.round(log.calories)}</p>
                  <button
                    onClick={() => log.id && removeLog(log.id)}
                    className="w-7 h-7 rounded-lg bg-red-50 dark:bg-red-900/20 flex items-center justify-center"
                  >
                    <Trash2 size={13} className="text-red-400" />
                  </button>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </Card>

      {/* Favorites */}
      {favFoods.length > 0 && (
        <Card className="mb-4">
          <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">⭐ Favorites</p>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {favFoods.map(food => (
              <button
                key={food.id}
                onClick={() => { addFood(food); }}
                className="flex-shrink-0 flex flex-col items-center gap-1 p-3 rounded-2xl bg-glow-blush dark:bg-dark-surface min-w-[80px] active:scale-95 transition-transform"
              >
                <span className="text-2xl">{food.emoji || "🍽️"}</span>
                <span className="text-[10px] font-medium text-center leading-tight">{food.name.split(" ").slice(0, 2).join(" ")}</span>
                <span className="text-[9px] text-gray-400">{food.calories} kcal</span>
              </button>
            ))}
          </div>
        </Card>
      )}

      {/* Food Search Modal */}
      <AnimatePresence>
        {showSearch && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-end"
            onClick={e => { if (e.target === e.currentTarget) { setShowSearch(false); setSearch(""); } }}
          >
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="w-full max-w-md mx-auto glass rounded-t-3xl p-4 max-h-[85vh] flex flex-col"
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-display text-lg font-bold">Add to {MEALS.find(m => m.id === activeMeal)?.label}</h2>
                <button onClick={() => { setShowSearch(false); setSearch(""); }} className="w-8 h-8 rounded-full bg-gray-100 dark:bg-dark-surface flex items-center justify-center">
                  <X size={16} />
                </button>
              </div>

              {/* Search Input */}
              <div className="relative mb-3">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  value={search}
                  onChange={e => handleSearch(e.target.value)}
                  placeholder="Search 80+ Indian foods..."
                  className="input-glow pl-9"
                  autoFocus
                />
              </div>

              {/* Custom Entry Hint */}
              {search && !filteredFoods.length && (
                <button
                  onClick={() => { setShowCustom(true); setShowSearch(false); }}
                  className="mb-3 p-3 rounded-2xl border-2 border-dashed border-glow-pink/30 text-sm text-glow-rose text-center"
                >
                  + Add "{search}" as custom food
                </button>
              )}

              {/* Food List */}
              <div className="overflow-y-auto flex-1 space-y-1.5 pb-4">
                {filteredFoods.map(food => (
                  <FoodSearchItem
                    key={food.id}
                    food={food}
                    servings={servings[food.id!] || 1}
                    onServingsChange={(s) => setServings(prev => ({ ...prev, [food.id!]: s }))}
                    onAdd={() => addFood(food)}
                    onFavorite={() => toggleFavorite(food)}
                  />
                ))}
              </div>

              <button
                onClick={() => { setShowCustom(true); setShowSearch(false); }}
                className="w-full py-3 rounded-2xl border border-dashed border-glow-lavender/40 text-sm text-gray-500 font-medium mt-2"
              >
                + Add custom food / meal
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Custom Food Modal */}
      <AnimatePresence>
        {showCustom && (
          <CustomFoodModal
            meal={activeMeal}
            initialName={search}
            onClose={() => { setShowCustom(false); setSearch(""); }}
            onAdd={() => { loadData(); setShowCustom(false); setSearch(""); }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function FoodSearchItem({ food, servings, onServingsChange, onAdd, onFavorite }: {
  food: FoodItem;
  servings: number;
  onServingsChange: (s: number) => void;
  onAdd: () => void;
  onFavorite: () => void;
}) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div className="rounded-2xl bg-glow-blush/40 dark:bg-dark-surface/50 overflow-hidden">
      <div className="flex items-center gap-3 p-3" onClick={() => setExpanded(!expanded)}>
        <span className="text-xl flex-shrink-0">{food.emoji || "🍽️"}</span>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold truncate">{food.name}</p>
          <p className="text-xs text-gray-400">{food.calories} kcal · {food.protein}g P · {food.servingSize} {food.servingUnit}</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={e => { e.stopPropagation(); onFavorite(); }} className="w-7 h-7 flex items-center justify-center">
            {food.isFavorite ? <Star size={15} className="text-glow-gold fill-glow-gold" /> : <StarOff size={15} className="text-gray-300" />}
          </button>
          <ChevronDown size={15} className={cn("text-gray-400 transition-transform", expanded && "rotate-180")} />
        </div>
      </div>
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: "auto" }}
            exit={{ height: 0 }}
            className="overflow-hidden"
          >
            <div className="px-3 pb-3 space-y-3">
              {/* Macros grid */}
              <div className="grid grid-cols-3 gap-2">
                {[
                  { label: "Protein", value: `${food.protein}g`, color: "#C8B6E2" },
                  { label: "Carbs", value: `${food.carbs}g`, color: "#93C5FD" },
                  { label: "Fat", value: `${food.fat}g`, color: "#FCD34D" },
                ].map(m => (
                  <div key={m.label} className="text-center p-1.5 rounded-xl" style={{ background: `${m.color}20` }}>
                    <p className="text-xs font-bold" style={{ color: m.color }}>{m.value}</p>
                    <p className="text-[9px] text-gray-400">{m.label}</p>
                  </div>
                ))}
              </div>
              {/* Servings control */}
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500">Servings:</span>
                <div className="flex items-center gap-3">
                  <button onClick={() => onServingsChange(Math.max(0.5, servings - 0.5))}
                    className="w-7 h-7 rounded-full bg-white dark:bg-dark-card flex items-center justify-center font-bold text-glow-rose shadow-sm">−</button>
                  <span className="text-sm font-bold w-8 text-center">{servings}</span>
                  <button onClick={() => onServingsChange(servings + 0.5)}
                    className="w-7 h-7 rounded-full bg-white dark:bg-dark-card flex items-center justify-center font-bold text-glow-rose shadow-sm">+</button>
                </div>
                <span className="text-xs font-semibold text-glow-rose">{Math.round(food.calories * servings)} kcal</span>
              </div>
              <button onClick={onAdd} className="btn-primary w-full py-2.5 text-sm">
                <Check size={15} /> Add to {activeMeal}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
  function activeMeal() { return ""; }
}

function CustomFoodModal({ meal, initialName, onClose, onAdd }: {
  meal: Meal;
  initialName: string;
  onClose: () => void;
  onAdd: () => void;
}) {
  const [form, setForm] = useState({
    name: initialName, calories: "", protein: "", carbs: "", fat: "", fiber: "0",
    sugar: "0", sodium: "0", servingSize: "1", servingUnit: "serving"
  });
  const today = getTodayString();

  async function handleSubmit() {
    if (!form.name || !form.calories) return;
    const food: Omit<FoodItem, "id"> = {
      name: form.name,
      calories: parseFloat(form.calories) || 0,
      protein: parseFloat(form.protein) || 0,
      carbs: parseFloat(form.carbs) || 0,
      fat: parseFloat(form.fat) || 0,
      fiber: parseFloat(form.fiber) || 0,
      sugar: parseFloat(form.sugar) || 0,
      sodium: parseFloat(form.sodium) || 0,
      servingSize: parseFloat(form.servingSize) || 1,
      servingUnit: form.servingUnit,
      category: "Custom",
      isCustom: true,
    };
    const foodId = await db.foods.add(food as FoodItem);
    await db.mealLogs.add({
      date: today, meal,
      foodId: foodId as number,
      foodName: form.name,
      servings: 1,
      calories: food.calories, protein: food.protein, carbs: food.carbs,
      fat: food.fat, fiber: food.fiber, sugar: food.sugar, sodium: food.sodium,
      createdAt: Date.now(),
    } as MealLog);
    onAdd();
  }

  const field = (label: string, key: keyof typeof form, suffix?: string) => (
    <div>
      <label className="text-xs font-medium text-gray-500 block mb-1">{label}{suffix ? ` (${suffix})` : ""}</label>
      <input
        value={form[key]}
        onChange={e => setForm(prev => ({ ...prev, [key]: e.target.value }))}
        className="input-glow"
        placeholder="0"
        type="number"
        inputMode="decimal"
      />
    </div>
  );

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-end"
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}
    >
      <motion.div
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        exit={{ y: "100%" }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className="w-full max-w-md mx-auto glass rounded-t-3xl p-5 max-h-[90vh] overflow-y-auto"
      >
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-display text-lg font-bold">Custom Food</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-gray-100 dark:bg-dark-surface flex items-center justify-center">
            <X size={16} />
          </button>
        </div>

        <div className="space-y-3">
          <div>
            <label className="text-xs font-medium text-gray-500 block mb-1">Food Name *</label>
            <input
              value={form.name}
              onChange={e => setForm(prev => ({ ...prev, name: e.target.value }))}
              className="input-glow"
              placeholder="e.g. Homemade Dal Tadka"
            />
          </div>
          {field("Calories *", "calories", "kcal")}
          {field("Protein", "protein", "g")}
          {field("Carbs", "carbs", "g")}
          {field("Fat", "fat", "g")}
          <div className="grid grid-cols-2 gap-3">
            {field("Fiber", "fiber", "g")}
            {field("Sugar", "sugar", "g")}
          </div>
          {field("Sodium", "sodium", "mg")}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-gray-500 block mb-1">Serving Size</label>
              <input
                value={form.servingSize}
                onChange={e => setForm(prev => ({ ...prev, servingSize: e.target.value }))}
                className="input-glow"
                type="number"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-gray-500 block mb-1">Unit</label>
              <input
                value={form.servingUnit}
                onChange={e => setForm(prev => ({ ...prev, servingUnit: e.target.value }))}
                className="input-glow"
                placeholder="g / cup / piece"
              />
            </div>
          </div>
        </div>

        <div className="flex gap-3 mt-5">
          <button onClick={onClose} className="flex-1 btn-ghost border border-gray-200 dark:border-dark-border py-3">Cancel</button>
          <button onClick={handleSubmit} className="flex-1 btn-primary py-3">Add Food</button>
        </div>
      </motion.div>
    </motion.div>
  );
}
