"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, X, TrendingDown, TrendingUp, Minus, Camera } from "lucide-react";
import PageHeader from "@/components/layout/PageHeader";
import Card from "@/components/ui/Card";
import { db, WeightLog, getTodayString, calculateBMI, getBMICategory } from "@/lib/db";
import { estimateGoalDate, getSetting as getSettingUtil } from "@/lib/utils";
import { format, subDays } from "date-fns";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS, CategoryScale, LinearScale, PointElement,
  LineElement, Tooltip, Filler
} from "chart.js";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Filler);

export default function WeightPage() {
  const [logs, setLogs] = useState<WeightLog[]>([]);
  const [weight, setWeight] = useState("");
  const [notes, setNotes] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [currentWeight, setCurrentWeight] = useState(70);
  const [goalWeight, setGoalWeight] = useState(65);
  const [height, setHeight] = useState(170);
  const today = getTodayString();

  useEffect(() => { loadData(); }, []);

  async function loadData() {
    const all = await db.weightLogs.orderBy("date").reverse().limit(90).toArray();
    setLogs(all.reverse());

    const [cw, gw, h] = await Promise.all([
      db.settings.where("key").equals("currentWeight").first(),
      db.settings.where("key").equals("goalWeight").first(),
      db.settings.where("key").equals("height").first(),
    ]);
    setCurrentWeight(parseFloat(cw?.value || "70"));
    setGoalWeight(parseFloat(gw?.value || "65"));
    setHeight(parseFloat(h?.value || "170"));
  }

  async function saveWeight() {
    const w = parseFloat(weight);
    if (!w || isNaN(w)) return;
    const bmi = calculateBMI(w, height);
    const existing = await db.weightLogs.where("date").equals(today).first();
    if (existing?.id) {
      await db.weightLogs.update(existing.id, { weight: w, bmi, notes, createdAt: Date.now() });
    } else {
      await db.weightLogs.add({ date: today, weight: w, bmi, notes, createdAt: Date.now() });
    }
    await db.settings.where("key").equals("currentWeight").first().then(async setting => {
      if (setting?.id) await db.settings.update(setting.id, { value: w.toString() });
    });
    setCurrentWeight(w);
    setWeight("");
    setNotes("");
    setShowAdd(false);
    await loadData();
  }

  const latestLog = logs.length > 0 ? logs[logs.length - 1] : null;
  const prevLog = logs.length > 1 ? logs[logs.length - 2] : null;
  const bmi = calculateBMI(currentWeight, height);
  const bmiInfo = getBMICategory(bmi);
  const weightDiff = latestLog && prevLog ? (latestLog.weight - prevLog.weight) : 0;
  const totalDiff = logs.length > 0 ? (logs[logs.length - 1].weight - logs[0].weight) : 0;
  const toGoal = currentWeight - goalWeight;
  const goalDate = toGoal > 0 ? estimateGoalDate(currentWeight, goalWeight) : null;

  // Last 30 days chart data
  const chartLogs = logs.slice(-30);
  const chartLabels = chartLogs.map(l => format(new Date(l.date), "d MMM"));
  const chartData = chartLogs.map(l => l.weight);

  return (
    <div className="page-container">
      <PageHeader
        title="Weight"
        emoji="⚖️"
        subtitle="Track your journey"
        rightElement={
          <button onClick={() => setShowAdd(true)} className="btn-primary py-2 px-4 text-xs">
            <Plus size={14} /> Log
          </button>
        }
      />

      {/* Current Stats */}
      <Card className="mb-4">
        <div className="flex items-end justify-between mb-4">
          <div>
            <p className="text-xs text-gray-400 font-medium mb-1">Current Weight</p>
            <div className="flex items-baseline gap-1">
              <span className="font-display text-4xl font-bold text-gradient">{currentWeight}</span>
              <span className="text-gray-400">kg</span>
            </div>
            {weightDiff !== 0 && (
              <div className={`flex items-center gap-1 mt-1 text-xs font-semibold ${
                weightDiff < 0 ? "text-emerald-500" : "text-red-400"
              }`}>
                {weightDiff < 0 ? <TrendingDown size={13} /> : <TrendingUp size={13} />}
                {Math.abs(weightDiff).toFixed(1)}kg from last entry
              </div>
            )}
          </div>
          <div className="text-right">
            <p className="text-xs text-gray-400">BMI</p>
            <p className="font-bold text-xl">{bmi}</p>
            <span
              className="text-xs px-2 py-0.5 rounded-full font-semibold"
              style={{ background: `${bmiInfo.color}20`, color: bmiInfo.color }}
            >
              {bmiInfo.label}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3 pt-3 border-t border-glow-pink/10">
          <div className="text-center">
            <p className="text-xs text-gray-400">Goal</p>
            <p className="font-bold">{goalWeight}kg</p>
          </div>
          <div className="text-center border-x border-glow-pink/10">
            <p className="text-xs text-gray-400">To Goal</p>
            <p className={`font-bold ${toGoal <= 0 ? "text-emerald-500" : ""}`}>
              {toGoal <= 0 ? "🎉 Reached!" : `${toGoal.toFixed(1)}kg`}
            </p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-400">Est. Date</p>
            <p className="font-bold text-xs">{goalDate || "—"}</p>
          </div>
        </div>

        {toGoal > 0 && (
          <div className="mt-3">
            <div className="flex justify-between text-xs text-gray-400 mb-1">
              <span>{goalWeight}kg</span>
              <span>{currentWeight}kg (now)</span>
              <span>{Math.max(currentWeight, goalWeight + 10)}kg</span>
            </div>
            <div className="h-2.5 rounded-full bg-gray-100 dark:bg-gray-800 overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-glow-lavender transition-all duration-700"
                style={{ width: `${Math.max(5, 100 - (toGoal / 20) * 100)}%` }}
              />
            </div>
          </div>
        )}
      </Card>

      {/* Weight Chart */}
      {chartData.length > 1 && (
        <Card className="mb-4">
          <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">Weight Trend</p>
          <div className="h-48">
            <Line
              data={{
                labels: chartLabels,
                datasets: [
                  {
                    label: "Weight",
                    data: chartData,
                    borderColor: "#C8B6E2",
                    backgroundColor: "rgba(200,182,226,0.1)",
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: "#C8B6E2",
                    pointRadius: 4,
                  },
                  {
                    label: "Goal",
                    data: Array(chartData.length).fill(goalWeight),
                    borderColor: "#34D399",
                    borderDash: [4, 4],
                    borderWidth: 1.5,
                    pointRadius: 0,
                    tension: 0,
                  },
                ],
              }}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                  x: { grid: { display: false }, ticks: { font: { size: 9 }, color: "#9CA3AF", maxTicksLimit: 6 } },
                  y: {
                    grid: { color: "rgba(0,0,0,0.04)" },
                    ticks: {
                      font: { size: 9 },
                      color: "#9CA3AF",
                      callback: (v: unknown) => `${v}kg`,
                    },
                  },
                },
              }}
            />
          </div>
          <div className="flex gap-4 mt-2 text-xs text-gray-400">
            <span className="flex items-center gap-1"><span className="w-3 h-1 rounded-full bg-glow-lavender inline-block" /> Weight</span>
            <span className="flex items-center gap-1"><span className="w-3 h-1 rounded-full bg-emerald-400 inline-block border-dashed" /> Goal</span>
          </div>
        </Card>
      )}

      {/* Total Progress */}
      {logs.length > 1 && (
        <Card className="mb-4">
          <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">Overall Progress</p>
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${totalDiff < 0 ? "bg-emerald-100 dark:bg-emerald-900/20" : "bg-red-50 dark:bg-red-900/20"}`}>
              {totalDiff < 0 ? <TrendingDown className="text-emerald-500" /> : <TrendingUp className="text-red-400" />}
            </div>
            <div>
              <p className="text-sm font-semibold">
                {totalDiff < 0 ? `Lost ${Math.abs(totalDiff).toFixed(1)}kg` : `Gained ${totalDiff.toFixed(1)}kg`}
              </p>
              <p className="text-xs text-gray-400">Since {format(new Date(logs[0].date), "d MMM yyyy")}</p>
            </div>
          </div>
        </Card>
      )}

      {/* History */}
      {logs.length > 0 && (
        <Card>
          <p className="text-xs font-semibold text-glow-rose/60 uppercase tracking-wider mb-3">History</p>
          <div className="space-y-2">
            {[...logs].reverse().slice(0, 10).map((log, i) => {
              const prev = logs[logs.length - 2 - i];
              const diff = prev ? log.weight - prev.weight : null;
              return (
                <div key={log.id} className="flex items-center gap-3 py-2 border-b border-glow-pink/5 last:border-0">
                  <div className="w-10 h-10 rounded-xl bg-glow-blush dark:bg-dark-surface flex flex-col items-center justify-center">
                    <p className="text-xs font-bold leading-none">{format(new Date(log.date), "d")}</p>
                    <p className="text-[9px] text-gray-400">{format(new Date(log.date), "MMM")}</p>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold">{log.weight}kg</p>
                    {log.notes && <p className="text-xs text-gray-400 truncate">{log.notes}</p>}
                  </div>
                  <div className="text-right">
                    {diff !== null && (
                      <span className={`text-xs font-semibold ${diff < 0 ? "text-emerald-500" : diff > 0 ? "text-red-400" : "text-gray-400"}`}>
                        {diff > 0 ? "+" : ""}{diff.toFixed(1)}kg
                      </span>
                    )}
                    <p className="text-[9px] text-gray-400">BMI {log.bmi}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      )}

      {/* Add Weight Modal */}
      <AnimatePresence>
        {showAdd && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-end"
            onClick={e => { if (e.target === e.currentTarget) setShowAdd(false); }}
          >
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="w-full max-w-md mx-auto glass rounded-t-3xl p-5"
            >
              <div className="flex items-center justify-between mb-5">
                <h2 className="font-display text-lg font-bold">Log Weight</h2>
                <button onClick={() => setShowAdd(false)} className="w-8 h-8 rounded-full bg-gray-100 dark:bg-dark-surface flex items-center justify-center">
                  <X size={16} />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-xs font-medium text-gray-500 block mb-1.5">Weight (kg)</label>
                  <input
                    value={weight}
                    onChange={e => setWeight(e.target.value)}
                    className="input-glow w-full text-2xl font-bold text-center"
                    placeholder="70.0"
                    type="number"
                    step="0.1"
                    inputMode="decimal"
                    autoFocus
                  />
                  {weight && (
                    <p className="text-center text-xs text-gray-400 mt-1">
                      BMI: {calculateBMI(parseFloat(weight) || 0, height)} · {getBMICategory(calculateBMI(parseFloat(weight) || 0, height)).label}
                    </p>
                  )}
                </div>
                <div>
                  <label className="text-xs font-medium text-gray-500 block mb-1.5">Notes (optional)</label>
                  <input
                    value={notes}
                    onChange={e => setNotes(e.target.value)}
                    className="input-glow w-full"
                    placeholder="e.g. After workout, before breakfast..."
                  />
                </div>
              </div>

              <div className="flex gap-3 mt-5">
                <button onClick={() => setShowAdd(false)} className="flex-1 btn-ghost border border-gray-200 dark:border-dark-border py-3">Cancel</button>
                <button onClick={saveWeight} className="flex-1 btn-primary py-3">Save</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
